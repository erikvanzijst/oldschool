import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;


class DistributedJobQueue extends UnicastRemoteObject
  implements DistributedJobQueueInterface {

  // This class keeps track of all the local jobqueues.
  // Each worker has an instance of this class.
	
  static final int MASTER_CPU = 0;

  private LocalJobQueue myQueue;
  private DistributedJobQueueInterface[] remoteQueues;

  int nrRegisteredQueues;
  int myCPU;
  int nrHosts;

  // Fields used for termination detection.
  private int work, idle, finished;

  public DistributedJobQueue(int size, int nrHosts) throws RemoteException {
    myQueue = new LocalJobQueue(size);
    this.nrHosts = nrHosts;
    work = idle = finished = 0;
    nrRegisteredQueues = 0;
    remoteQueues = new DistributedJobQueueInterface[nrHosts];
  }
  

  public synchronized void registerMaster() {
    // I am the master, so store myself at index 0 in remoteQueues.
    remoteQueues[MASTER_CPU] = this;
    nrRegisteredQueues++;
    myCPU = MASTER_CPU;

    while(nrRegisteredQueues != nrHosts) {
      try {
	wait();
      } catch (Exception e) {
	System.out.println("Interrupted");
	System.exit(1);
      }
    }

    notifyAll();
  }


  public void registerYourself(DistributedJobQueueInterface masterQueue) {
    Register result = null;

    try {
      result = masterQueue.register(this);
    } catch (Exception e) {
      System.out.println("Could not register myself");
      e.printStackTrace();
      System.exit(1);
    }

    myCPU = result.cpu;
    remoteQueues = result.q;
  }


  public synchronized Register
    register(DistributedJobQueueInterface q) throws RemoteException {
    // Be sure the master has registered himself first.
    while(nrRegisteredQueues == 0) {
      try {
	wait();
      } catch (Exception e) {
	System.out.println("Interrupted.");
	System.exit(1);
      }
    }

    Register result = new Register();
    remoteQueues[nrRegisteredQueues] = q;
    result.cpu = nrRegisteredQueues;
    result.q = remoteQueues;
    nrRegisteredQueues++;

    while(nrRegisteredQueues != nrHosts) {
      try {
	wait();
      } catch (Exception e) {
	System.out.println("Interrupted");
	System.exit(1);
      }
    }

    notifyAll();
    return result;
  }


  public void addJob(Job j) {

    // ....

  }


  public Job getJob() {

    // ....

  }



  /* these methods are used for termination detection, and
     are invoked via RMI at the master CPU. */

  public synchronized void announce() throws RemoteException {
    do {
      if(idle <= work) break;
      else if(idle > work && finished == 0) {
	work = idle;
	break;
      } else {
	try {
	  wait();
	} catch (Exception e) {
	  System.out.println("Interrupted.");
	}
      }
    } while(true);

    notifyAll();
  }


  public synchronized void idle() throws RemoteException {
    do {
      if(finished == 0) {
	idle++;
	break;
      } else {
	try {
	  wait();
	} catch (Exception e) {
	  System.out.println("Interrupted.");
	}
      }
    } while(true);

    notifyAll();
  }


  public synchronized boolean allDone() throws RemoteException {
    boolean cont = true;

    do {
      if(idle == nrHosts && work == 0) {
	finished++;
	if(finished == nrHosts) {
	  idle = 0;
	  finished = 0;
	}

	notifyAll();
	return true;
      } else if(work > 0) {
	work--;
	idle--;

	notifyAll();
	return false;
      } else {
	try {
	  wait();
	} catch (Exception e) {
	  System.out.println("Interrupted.");
	}
      }
    } while(cont);
        
    return false; // never reached
  }

}
