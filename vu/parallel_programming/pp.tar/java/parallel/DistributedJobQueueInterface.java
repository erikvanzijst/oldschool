import java.rmi.*;


public interface DistributedJobQueueInterface extends java.rmi.Remote {

    // These are only invoked when we are the master.

    Register register(DistributedJobQueueInterface q) throws RemoteException;
    void announce() 				throws RemoteException;
    void idle() 				throws RemoteException;
    boolean allDone() 				throws RemoteException;
}
