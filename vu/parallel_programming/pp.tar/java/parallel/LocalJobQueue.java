class LocalJobQueue {

    private Job[] jobArray;
    private int size, first, last, count;


    LocalJobQueue(int size) {
	this.size = size;
	jobArray = new Job[size];
	first = last = count = 0;
    }


    void addJob(Job j) {
	if(count >= size) {
	    System.out.println("ERROR: Queue overflow!");
	    System.exit(1);
	}

	jobArray[last] = j;
	last++;
	if(last >= size)
	    last = 0;
	count++;
    }


    Job getJobFIFO() {
	if(count <= 0)
	    return null;

	Job firstJob = jobArray[first];
	first++;
	if(first >= size)
	    first = 0;
	count--;

	return firstJob;
    }


    Job getJobLIFO() {
	if(count <= 0)
	    return null;

	Job lastJob = jobArray[last - 1];
	last--;
	if(last < 0)
	    last = size - 1;
	count--;

	return lastJob;
    }
}
