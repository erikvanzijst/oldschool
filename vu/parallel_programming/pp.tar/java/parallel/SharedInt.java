import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;


class SharedInt extends UnicastRemoteObject implements SharedIntInterface {

    int val;


    SharedInt() throws RemoteException {
	val = 0;
    }


    public synchronized int get() throws RemoteException {
	return val;
    }


    public synchronized void set(int val) throws RemoteException {
	this.val = val;
    }


    public synchronized void inc() throws RemoteException {
	val++;
    }


    public synchronized void dec() throws RemoteException {
	val--;
    }
}
