import java.rmi.*;
import java.net.*;
import java.rmi.registry.*;


class Ida {

    static final int MAX_JOBS = 10000;

    Game puzzle;
    SharedIntInterface solutions;
    DistributedJobQueue q;
    Registry local;


    Ida() {
    }


    private void Move(Job j, int dx, int dy) {
	int x = j.blankX + dx;
	int y = j.blankY + dy;
	int v = j.board[((x - 1) * Game.NSQRT) + y - 1];

	j.bound--;
	j.distance += -puzzle.Distance(v, x, y) + puzzle.Distance(v, j.blankX,
								  j.blankY);

	j.board[((j.blankX - 1) * Game.NSQRT) + j.blankY - 1] = (byte)v;
	j.blankX = x;
	j.blankY = y;
    }


    private int MakeMoves(Job[] jobs, int n) {
	int j = n;

	if(jobs[j].blankX > 1) {
	    n++;
	    jobs[n] = new Job(jobs[j]);
	    Move(jobs[n], -1, 0);
	}

	if(jobs[j].blankX < Game.NSQRT) {
	    n++;
	    jobs[n] = new Job(jobs[j]);
	    Move(jobs[n], 1, 0);
	}

	if(jobs[j].blankY > 1) {
	    n++;
	    jobs[n] = new Job(jobs[j]);
	    Move(jobs[n], 0, -1);
	}

	if(jobs[j].blankY < Game.NSQRT) {
	    n++;
	    jobs[n] = new Job(jobs[j]);
	    Move(jobs[n], 0, 1);
	}

	return n;
    }


    private void initWorker(String masterName) {
	DistributedJobQueueInterface mastersQueue = null;
	boolean retry = true;
	do {
	    try {
		Thread.sleep(1000);
		solutions = (SharedIntInterface)
		    Naming.lookup("//" + masterName + "/solutions");
		mastersQueue = (DistributedJobQueueInterface)
		    Naming.lookup("//" + masterName + "/queue");
		retry = false;
	    } catch (Exception e) {
		System.out.print(".");
		System.out.flush();
	    }
	} while (retry);

	// Register my queue with master.
	// This operation will block until all queues are registered.
	q.registerYourself(mastersQueue);
    }


    private void initMaster(String hostName) {
	try {
	    // Create shared in object for the number of solutions found.
	    solutions = new SharedInt();
	    Naming.bind("//" + hostName + "/solutions", solutions);
	    System.out.println("solutions bound in registry " + "//" +
			       hostName + "/solutions");
	    Naming.bind("//" + hostName + "/queue", q);
	    System.out.println("queue bound in registry " +"//" +
			       hostName + "/queue");
	} catch (Exception e) {
	    System.out.println("could not bind variables");
	    System.out.println(e);
	    System.exit(1);
	}
	// Block until everybody has registered his queue.
	System.out.println("Waiting for clients");
	q.registerMaster();
	System.out.println("All clients found");
    }


    private void doMaster(int length) {
	// Initialize starting position.
	Job j = new Job();
	j.distance = 0;
	for(int y = 1; y <= Game.NSQRT; y++) {
	    for(int x = 1; x <= Game.NSQRT; x++) {
		int v = puzzle.Value(x, y);
		j.board[((x - 1) * Game.NSQRT) + y - 1] = (byte)v;
		j.distance += puzzle.Distance(v, x, y);
		if(v == 0) {
		    j.blankX = x;
		    j.blankY = y;
		}
	    }
	}

	System.out.println("Running ida " + length);
	int currSolutions = 0;
	
	long start = System.currentTimeMillis();
	
	// ....
	
	long stop = System.currentTimeMillis();
	double time = (double) stop - start;
	time /= 1000.0;

	System.out.println("\napplication ida (" + length + ") took = " +
                           time + " seconds, result = " + currSolutions +
                           " solutions of " + j.bound + " steps");
    }


    private void shutdownMaster(String hostName) {
	try {
	    Naming.unbind("//" + hostName + "/solutions");
	    System.out.println("solutions unbound in registry");
	    Naming.unbind("//" + hostName + "/queue");
	    System.out.println("queue unbound in registry");
	} catch (Exception e) {
	    System.out.println("could not unbind variables");
	    System.exit(1);
	}
	System.exit(0);
    }


    private void startRMIenv() {
        // Start the registry.
        try {
            // First try to create a registry object
            local = LocateRegistry.createRegistry(Registry.REGISTRY_PORT);
        } catch (java.rmi.RemoteException e) {
            // Didn't work; registry allready present ?
            try {
                local = LocateRegistry.getRegistry();
            } catch (java.rmi.RemoteException e2) {
                System.out.println("Failed to create registry : " +
				   e + " " + e2);
		System.exit(1);
            }
        }
        // Start a security manager.
        // System.setSecurityManager(new RMISecurityManager()); // does not work for java 1.2 --Rob
    }


    void start(String argv[]) {
	DasInfo info = new DasInfo();

	// Use some suitable default values.
	int length = 58;

	if(argv.length == 1) {
	    length = Integer.parseInt(argv[0]);
	} else if(argv.length != 0) {
	    System.out.println("Usage: prun runjava #hosts Ida [length]");
	    System.exit(1);
	}

	puzzle = new Game();
	puzzle.Init(length);

	// Everybody needs a DistibutedJobQueue.
	try {
	    q = new DistributedJobQueue(MAX_JOBS, info.totalHosts());
	} catch (Exception e) {
	    System.out.println("Could not create job queue");
	    System.exit(1);
	}


	if(info.hostNumber() == 0) { 	// I am the master!

	    startRMIenv();
	    initMaster(info.hostName());
	    doMaster(length);
	    shutdownMaster(info.hostName());

	} else { 			// I am just another client.

	    startRMIenv();
	    initWorker(info.getHost(0));

            // ....
            
	    System.exit(0);
	}
    }


    public static void main(String argv[]) {
	new Ida().start(argv);
    }
}
