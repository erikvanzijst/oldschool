/* 
   This class is used by DistributedJobQueue's register method,
   which needs to return two values.
   We can't pass the queue as a parameter, as RMI uses call by value.
   Because we need to specify the return type in the interface of
   DistributedJobQueue, this class is used outside DistributedJobQueue.java.
*/

class Register implements java.io.Serializable {

    DistributedJobQueueInterface[] q;
    int cpu;
}
