import java.rmi.*;


public interface SharedIntInterface extends java.rmi.Remote {

    int get() 		throws RemoteException;
    void set(int val) 	throws RemoteException;
    void inc() 		throws RemoteException;
    void dec() 		throws RemoteException;
}
