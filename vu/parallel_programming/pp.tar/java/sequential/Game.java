class Game {

    static final int
	NSQRT		= 4,
	NPUZZLE		= NSQRT * NSQRT - 1,
	BRANCH_FACTOR	= 3;


    private int[][] start = new int[NSQRT + 1][NSQRT + 1];
    private Position[] goal = new Position[NPUZZLE + 1];


    Game() {
	for(int i = 0; i <= NPUZZLE; i++)
	    goal[i] = new Position();
    }


    int Value(int x, int y) {
	return start[x][y];
    }


    int Distance(int v, int x, int y) {
	/* Returns the (Manhatten) distance of Piece v at position (x,y)
	   0 <=  v  <= Npuzzle		-- Value range (0 denotes blank)
	   1 <= x,y <= Nsqrt		-- Index range */
	if(v == 0)
	    return 0;
	return Math.abs(goal[v].x - x) + Math.abs(goal[v].y - y);
    }


    int[][] Step(int[][] board, int x, int y, int n, int m) {
	int v = board[x][y];
	board[x][y] = board[n][m];
	board[n][m] = v;
	return board;
    }


    void Init(int length) {
	// Sets up a starting position based on 'length' random moves

	int[][][] path = new int[length + 1][NSQRT + 1][NSQRT + 1];

	int v = 0;
	for(int j = 1; j <= NSQRT; j++) {
	    for(int i = 1; i <= NSQRT; i++) {
		goal[v].x = i;
		goal[v].y = j;
		path[0][i][j] = v;
		v++;
	    }
	}

	// Generate a starting position by shuffling the blanc around
	// in cycles. Just cycling along the outer bounds of the
	// board yields low quality start positions whose solutions
	// require less than 'length' steps. Therefore we use two
	// alternating cycling dimensions.

	int N = NSQRT - 1;
	int x = 1;
	int y = 1; // position of the blanc
	int nx, ny;

	for(int i = 1; i <= length; i++) {
	    if(x == 1) {
		if(y == N) {
		    nx = x + 1;
		    ny = y;
		} else {
		    nx = x;
		    ny = y + 1;
		    if(y == 1) {
			if(N < NSQRT)
			    N = NSQRT;
			else
			    N = NSQRT - 1;
		    }
		}
	    } else if (x == N) {
		if(y == 1) {
		    nx = x - 1;
		    ny = y;
		} else {
		    nx = x;
		    ny = y - 1;
		}
	    } else {
		if(y == N) {
		    nx = x + 1;
		    ny = y;
		} else {
		    nx = x - 1;
		    ny = y;
		}
	    }

	    path[i] = Step(path[i - 1], x, y, nx, ny);
	    x = nx;
	    y = ny;
	}

	for(int j = 1; j <= NSQRT; j++) {
	    for(int i = 1; i <= NSQRT; i++) {
		v = path[length][i][j];
		start[i][j] = v;
	    }
	}
    }
}
