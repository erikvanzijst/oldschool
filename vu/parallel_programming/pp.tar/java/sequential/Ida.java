class Ida {

    static int solutions = 0;

    Game puzzle;
    Job j;


    Ida(int length) {
	puzzle = new Game();
	puzzle.Init(length);

	/* Initialize starting position. */
	j = new Job();
	j.prevDx = 0;
	j.prevDy = 0;
	j.distance = 0;
	for(int y = 1; y <= Game.NSQRT; y++) {
	    for(int x = 1; x <= Game.NSQRT; x++) {
		int v = puzzle.Value(x, y);
		j.board[((x - 1) * Game.NSQRT) + y - 1] = (byte)v;
		j.distance += puzzle.Distance(v, x, y);
		if(v == 0) {
		    j.blankX = x;
		    j.blankY = y;
		}
	    }
	}
    }


    private void Move(Job j, int dx, int dy) {
	int x = j.blankX + dx;
	int y = j.blankY + dy;
	int v = j.board[((x - 1) * Game.NSQRT) + y - 1];

	j.bound--;
	j.distance += -puzzle.Distance(v, x, y) + puzzle.Distance(v, j.blankX,
								  j.blankY);

	j.board[((j.blankX - 1) * Game.NSQRT) + j.blankY - 1] = (byte)v;
	j.prevDx = dx;
	j.prevDy = dy;
	j.blankX = x;
	j.blankY = y;
    }


    private int MakeMoves(Job[] jobs, int n) {
	// Optimization: don't generate (cyclic) moves that undo the last move.
	int j = n;

	if(jobs[j].blankX > 1 && jobs[j].prevDx != 1) {
	    n++;
	    jobs[n] = new Job(jobs[j]);
	    Move(jobs[n], -1, 0);
	}

	if(jobs[j].blankX < Game.NSQRT && jobs[j].prevDx != -1) {
	    n++;
	    jobs[n] = new Job(jobs[j]);
	    Move(jobs[n], 1, 0);
	}

	if(jobs[j].blankY > 1 && jobs[j].prevDy != 1) {
	    n++;
	    jobs[n] = new Job(jobs[j]);
	    Move(jobs[n], 0, -1);
	}

	if(jobs[j].blankY < Game.NSQRT && jobs[j].prevDy != -1) {
	    n++;
	    jobs[n] = new Job(jobs[j]);
	    Move(jobs[n], 0, 1);
	}

	return n;
    }
    

    private void Expand(Job[] jobs, int j) {
	if(jobs[j].distance == 0) {
	    solutions++;
	    return;
	}

	// Prune paths with too high estimates.
	if(jobs[j].distance > jobs[j].bound)
	    return;

	int child = MakeMoves(jobs, j);
	if(child > j) {
	    int mine = j + 1;
	    while(child >= mine) {
		Expand(jobs, child);
		child--;
	    }
	}
    }


    private void ExpandJob(Job j) {
	Job[] jobs = new Job[Game.BRANCH_FACTOR * j.bound + 1];

	jobs[0] = j;
	Expand(jobs, 0);
    }
 

    private void start(int length) {
	System.out.println("Running ida " + length);

	long start = System.currentTimeMillis();
	int bound = j.distance;
	System.out.print("Try bound ");
	System.out.flush();

	do {

	    System.out.print(bound + " ");
	    System.out.flush();
	    j.bound = bound;
	    ExpandJob(j);
	    bound += 2; /* Property of 15-puzzle and Manhattan distance */

	} while(solutions == 0);
	
	long stop = System.currentTimeMillis();
	double time = (double) stop - start;
	time /= 1000.0;

	System.out.println("\napplication ida (" + length + ") took = " +
			   time + " seconds, result = " + solutions +
			   " solutions of " + j.bound + " steps");
    }


    public static void main(String argv[]) {
	/* Use some suitable default values. */
	int length = 58;

	if(argv.length == 1) {
	    length = Integer.parseInt(argv[0]);
	} else if(argv.length != 0) {
	    System.out.println( "Usage: java Ida [length]");
	    System.exit(1);
	}

	new Ida(length).start(length);
    }
}
