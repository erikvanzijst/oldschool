class Job implements java.io.Serializable {

    byte[] board;
    int distance;
    int bound;
    int blankX, blankY;
    int prevDx, prevDy;


    Job() {
	board = new byte[Game.NSQRT * Game.NSQRT];
    }


    Job(Job j) {
	board = new byte[Game.NSQRT * Game.NSQRT];
	System.arraycopy(j.board, 0, board, 0, Game.NSQRT * Game.NSQRT);
	distance = j.distance;
	bound = j.bound;
	blankX = j.blankX;
	blankY = j.blankY;
	prevDx = j.prevDx;
	prevDy = j.prevDy;
    }
}
