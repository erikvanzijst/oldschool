class Position {

    int x, y;
}
