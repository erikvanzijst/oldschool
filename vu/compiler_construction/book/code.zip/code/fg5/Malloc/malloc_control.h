/* Control interface to malloc */

extern void Init_mem(void);
extern void Coalesce_free_chunks(void);
extern void Collect_garbage(void);
extern void Dump_memory(void);
