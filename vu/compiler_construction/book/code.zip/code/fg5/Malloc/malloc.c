/* Translation of outline code in chapter about memory allocation */

#include    "malloc.h"
#include    "malloc_control.h"

#define     Size_of_available_memory        1000

#define     True                            1
#define     False                           0
#define     Nil_pointer                     ((char *)0)

typedef struct {
    int size;
    int free;
} Adm;
#define     Administration_size             (sizeof (Adm))
#define     size_field(p)                   (((Adm *)(p))->size)
#define     free_field(p)                   (((Adm *)(p))->free)

static char Memory[Size_of_available_memory];
#define     Beginning_of_available_memory   (&Memory[0])

static char *First_chunk_pointer
    = Beginning_of_available_memory;
static char *One_past_available_memory
    = Beginning_of_available_memory + Size_of_available_memory;

static char *Pointer_to_free_block_of_size(int Block_size);
static char *Solution_to_out_of_memory_condition(void);

void
Init_mem(void) {
    size_field(First_chunk_pointer) = Size_of_available_memory;
    free_field(First_chunk_pointer) = True;
}

char *
Malloc(int Block_size) {
    char *Pointer;

    Pointer = Pointer_to_free_block_of_size(Block_size);
    if (Pointer != Nil_pointer) { return Pointer;}

    Coalesce_free_chunks();
    Pointer = Pointer_to_free_block_of_size(Block_size);
    if (Pointer != Nil_pointer) { return Pointer;}

    return Solution_to_out_of_memory_condition();
}

static char *
Pointer_to_free_block_of_size(int Block_size) {
    /* note that this is not a pure function */
    char *Chunk_pointer = First_chunk_pointer;
    int Requested_chunk_size = Administration_size + Block_size;

    while (Chunk_pointer != One_past_available_memory) {
        if (free_field(Chunk_pointer)
            && size_field(Chunk_pointer) - Requested_chunk_size >= 0) {
            /* large_enough chunk found */
            int Left_over_size = size_field(Chunk_pointer) - Requested_chunk_size;

            if (Left_over_size > Administration_size) {
                /* there_is_a_non-empty_left-over_chunk */
                char *Left_over_chunk_pointer;
                size_field(Chunk_pointer) = size_field(Chunk_pointer) - Left_over_size;
                Left_over_chunk_pointer
                    = Chunk_pointer + Requested_chunk_size;
                size_field(Left_over_chunk_pointer) = Left_over_size;
                free_field(Left_over_chunk_pointer) = True;
            }
            free_field(Chunk_pointer) = False;
            return Chunk_pointer + Administration_size;
        }
        else {
            /* try_next_chunk */
            Chunk_pointer = Chunk_pointer + size_field(Chunk_pointer);
        }
    }

    return Nil_pointer;
}

void
Free(char *Block_pointer) {
    char *Chunk_pointer = Block_pointer - Administration_size;
    free_field(Chunk_pointer) = True;
}

void
Coalesce_free_chunks(void) {
    char *Chunk_pointer_1 = First_chunk_pointer;
    char *Chunk_pointer_2 = Chunk_pointer_1 + size_field(Chunk_pointer_1);

    while (Chunk_pointer_2 != One_past_available_memory) {
        if (free_field(Chunk_pointer_1) && free_field(Chunk_pointer_2)) {
            size_field(Chunk_pointer_1)
                = size_field(Chunk_pointer_1) + size_field(Chunk_pointer_2);
            Chunk_pointer_2 = Chunk_pointer_1 + size_field(Chunk_pointer_1);
        }
        else {
            Chunk_pointer_1 = Chunk_pointer_2;
            Chunk_pointer_2 = Chunk_pointer_1 + size_field(Chunk_pointer_1);
        }
    }
}

static char *
Solution_to_out_of_memory_condition(void) {
    return 0;
}

#include    <stdio.h>

void
Dump_memory(void) {
    char *p;
    int cnt = 0;

    printf( "Beginning_of_available_memory = %d\n",
        Beginning_of_available_memory
    );
    p = Beginning_of_available_memory;
    while (p != One_past_available_memory) {
        printf("Block %d: size = %d, free = %c\n",
                cnt++, size_field(p), free_field(p) + '0'
        );
        p += size_field(p);
    }
    printf("\n");
}
