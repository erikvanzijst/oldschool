#include    <stdio.h>

#include    "malloc.h"
#include    "malloc_control.h"

static void
test_aligned(void) {
    char *p[500];
    int i = 0;

    while (p[i] = (char *)Malloc(16)) {i++;}
    Dump_memory();
    while (i) {Free(p[--i]);}
    Dump_memory();
    Coalesce_free_chunks();
    Dump_memory();
}

static void
test_unaligned(void) {
    char *p1;
    int around = 112;           /* just a funny number */

    p1 = (char *)Malloc(around - 1);
    printf("p1 = %d\n", p1);
    Dump_memory();
    if (p1) Free(p1);
    Dump_memory();
    Coalesce_free_chunks();
    Dump_memory();

    p1 = (char *)Malloc(around);
    printf("p1 = %d\n", p1);
    Dump_memory();
    if (p1) Free(p1);
    Dump_memory();
    Coalesce_free_chunks();
    Dump_memory();

    p1 = (char *)Malloc(around + 1);
    printf("p1 = %d\n", p1);
    Dump_memory();
    if (p1) Free(p1);
    Dump_memory();
    Coalesce_free_chunks();
    Dump_memory();
}

int
main(void) {
    Init_mem();

    printf("Testing aligned allocation and freeing\n");
    test_aligned();

    printf("Testing unaligned allocation and freeing\n");
    test_unaligned();

    return 0;
}
