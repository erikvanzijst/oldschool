/* User interface to malloc */

extern char *Malloc(int Block_size);
extern void Free(char *Block_pointer);
