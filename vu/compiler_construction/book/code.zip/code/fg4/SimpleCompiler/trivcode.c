#include    "stack.h"
int main(void) {
Push(7);
Push(1);
Push(5);
{
    int e_left = Pop(); int e_right = Pop();
    switch (43) {
    case '+': Push(e_left + e_right); break;
    case '*': Push(e_left * e_right); break;
    }}
{
    int e_left = Pop(); int e_right = Pop();
    switch (42) {
    case '+': Push(e_left + e_right); break;
    case '*': Push(e_left * e_right); break;
    }}
printf("%d\n", Pop()); /* print the result */
return 0;}
