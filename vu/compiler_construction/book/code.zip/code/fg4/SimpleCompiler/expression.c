#include    "stack.h"

void Expression_D(int digit) {
    Push(digit);
}

void Expression_P(int oper) {
    int e_left = Pop(); int e_right = Pop();
    switch (oper) {
    case '+': Push(e_left + e_right); break;
    case '*': Push(e_left * e_right); break;
    }
}

void Print(void) {
    printf("%d\n", Pop());
}
