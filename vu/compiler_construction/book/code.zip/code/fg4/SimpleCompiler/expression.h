extern void Expression_D(int digit);
extern void Expression_P(int oper);
extern void Print(void);
