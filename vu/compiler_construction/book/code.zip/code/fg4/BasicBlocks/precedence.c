#include	<stdio.h>
#include	<string.h>
#include	<ctype.h>

#include	"grammar.h"
#include	"precedence.h"
#include	"error.h"

#define	N_TOKENS	9

static const char precedence_table[][N_TOKENS+1] = {
	{' ',	'#', ';', '=', '+', '*', '(', ')', 'A', '0'},

	{'#',	'=', '<', ' ', ' ', '<', ' ', ' ', '<', ' '},
	{';',	'>', '>', ' ', ' ', '<', ' ', ' ', '<', ' '},
	{'=',	'>', '>', ' ', '<', '<', '<', ' ', '<', '<'},
	{'+',	'>', '>', ' ', '>', '<', '<', '>', '<', '<'},
	{'*',	'>', '>', '=', '>', '>', '<', '>', '<', '<'},
	{'(',	' ', ' ', ' ', '<', '<', '<', '=', '<', '<'},
	{')',	'>', '>', '>', '>', '>', ' ', '>', ' ', ' '},
	{'A',	'>', '>', '=', '>', '>', ' ', '>', ' ', ' '},
	{'0',	'>', '>', ' ', '>', '>', ' ', '>', ' ', ' '}
};

char
precedence(int t1, int t2) {
	int i;

	for(i = 1; i < N_TOKENS+1; i++) {
		if (precedence_table[i][0] == t1) {
			int j;

			for(j = 1; j < N_TOKENS+1; j++) {
				if (precedence_table[0][j] == t2)
					return precedence_table[i][j];
			}
		}
	}
	return ' ';
}

int
class_of(int t) {
	return (
		islower(t) ? 'A' :
		isdigit(t) ? '0' :
		t == '-' ? '+' :
		t == '/' ? '*' :
		t
	);
}
