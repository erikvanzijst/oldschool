extern void print_graph(const char *msg);
