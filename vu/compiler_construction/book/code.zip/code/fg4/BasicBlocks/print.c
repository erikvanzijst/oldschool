#include	<stdio.h>

#include	"node.h"
#include	"root.h"
#include	"print.h"

static void
print_identifier(int idf) {
	printf(" %c", idf);
}

static void
print_operand(int opnd) {
	printf(" @%d", opnd);
}

static void
print_operator(char optr) {
	printf(" %c", optr);
}

static void
print_deps(int n_deps, const int dep[]) {
	int i;

	if (n_deps == 0) return;

	printf(" out:");
	for (i = 0; i < n_deps; i++) {
		printf(" @%d", dep[i]);
	}
}

static void
print_node(const struct node *nd) {
	if (nd->operator == 0) {
		print_identifier(nd->left);
	}
	else {
		print_operand(nd->left);
	}
	
	if (nd->operator) {
		print_operator(nd->operator);
		if (nd->operator == '=') {
			print_identifier(nd->right);
		}
		else {
			print_operand(nd->right);
		}
	}
	else {
		printf("\t");		/* arbitrary */
	}

	printf("\t#in: %d;", nd->n_indeps);
	print_deps(nd->n_deps, nd->dep);

	printf("\n");
}

static void
print_nodes(void) {
	int i;

	for (i = 1; i < n_nodes; i++) {
		const struct node *nd = &node[i];

		if (is_empty_node(nd)) continue;

		printf("%2d:", i);
		print_node(nd);
	}
}

static void
print_roots(void) {
	int i;

	printf("root %s%s:",
		(root[0].index ? "node" : "variable"),
		(n_roots == 1 ? "" : "s")
	);
	for (i = 0; i < n_roots; i++) {
		if (root[i].index) {
			printf(" @%d", root[i].index);
		}
		else {
			printf(" %c", root[i].var);
		}
	}
}

void
print_graph(const char *msg) {
	printf("%s; ", msg);
	print_roots();
	printf("\n\n");
	print_nodes();
	printf("\n");
}
