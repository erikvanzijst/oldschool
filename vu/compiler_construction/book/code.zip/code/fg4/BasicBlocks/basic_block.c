#include	<stdio.h>
#include	<stdlib.h>

#include	"parser.h"
#include	"AST2dep.h"
#include	"dep2code.h"
#include	"basic_block.h"
#include	"print.h"

int s_flag = 0;
int v_flag = 0;
int V_flag = 0;

int
main(int argc, char *argv[]) {
	while (argc >= 2 && argv[1][0] == '-') {
		switch (argv[1][1]) {
		case 's':		/* common subexpression elimination */
			s_flag = 1;
			break;
		case 'v':		/* verbose output */
			v_flag = 1;
			break;
		case 'V':		/* detailed output */
			v_flag = 1;
			V_flag = 1;
			break;
		}
		argc--, argv++;
	}

	process_input();
	if (v_flag) print_graph("AST");

	AST_to_dep_graph();
	if (v_flag) print_graph("dependency graph");

	dep_graph_to_code();

	return 0;
}
