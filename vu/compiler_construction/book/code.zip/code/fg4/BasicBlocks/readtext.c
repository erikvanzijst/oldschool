#include	<stdio.h>
#include	<strings.h>

#include	"readtext.h"
#include	"error.h"

#define	MAX_PROG_LENGTH		10000
static char text[MAX_PROG_LENGTH];
static int text_length;
static int inpp;			/* input pointer */

static void
init_text(void) {
	text_length = inpp = 0;
}

void
read_text(void) {
	char line[MAX_PROG_LENGTH];
	char *OK;

	init_text();
	while ((OK = gets(line))) {
		int line_length = strlen(line);

		if (line[0] == '#') continue;
		if (line[0] == '.') break;
		if (text_length + line_length >= MAX_PROG_LENGTH)
			error("input", "text too long");
		strcpy(&text[text_length], line);
		text_length += line_length;
	}
	if (!OK) error("input", "text not terminated with a dot");
	strcpy(&text[text_length++], "#");
}

int
next_token(void) {
	/* skip lay-out */
	while (text[inpp] && text[inpp] <= 32) {
		inpp++;
	}
	return text[inpp++];
}

int
char_pos(void) {
	return inpp;
}
