extern void AST_to_dep_graph(void);
