#include	<ctype.h>

#include	"grammar.h"

/*
	To simplify the parser, the input for indirect assignment requires
	the destination to be between parentheses:  *(x) = 3.

        input:          assignment_list
        assignment_list:assignment | assignment_list ';' assignment
        assignment:     LETTER '=' expression
        assignment:     '*' par_expression '=' expression
        expression:     factor | expression ['+'|'-'] factor
        factor:         primary | factor ['*'|'/'] primary
        primary:        LETTER | DIGIT | par_expression
        par_expression: '(' expression ')'
*/

int
is_commutative(int optr) {
	return (optr == '+' || optr == '*');
}

const char *
instr_name(int optr) {
	return (
		optr == 0 ? "Load" :
		optr == '=' ? "Store" :
		optr == '\\' ? "Store_Indirect" :
		optr == '+' ? "Add" :
		optr == '-' ? "Subtr" :
		optr == '*' ? "Mult" :
		optr == '/' ? "Div" :
		"XXX"
	);
}

int
is_store_operator(int optr) {
	return (optr == '=' || optr == '\\');
}

const char *
storage_name(int opnd) {
	return (
		isdigit(opnd) ? "Const" :
		islower(opnd) ? "Mem" :
		isupper(opnd) ? "Reg" :
		"XXX"
	);
}
