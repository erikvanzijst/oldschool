extern int is_commutative(int optr);
extern const char *instr_name(int optr);
extern int is_store_operator(int optr);
extern const char *storage_name(int opnd);
