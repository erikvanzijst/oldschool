#define		MAX_DEPS	100
#define		MAX_NODES	100

/*	The AST is stored in the array node[MAX_NODES] in depth-first
	order.  So scanning the array from top to bottom does a
	depth-first left-to-right visit on the AST.
	
	The AST is stored in node[1..n_nodes-1].  Node[0] is not used,
	and n_nodes-1 is the actual number of nodes in the AST.

	There are 5 kinds of nodes:

	v		use of a variable [a-zA-Z]
	c		use of a constant [0-9]
	@N = v		definition of a variable [a-zA-Z]
	@N optr @N	operation on two nodes (opnd can be '\')
	0		empty nodes

	This is more restrictive than the format used in Figure 4.48:
	v is not allowed directly as an operand.  This is not fundamental;
	it just avoids having to distinguish too many cases.

	There are two kinds of dependencies: those implicitly arising from
	operands, and those explicitly mentioned in dep[].  The field
	n_indeps counts them all.
*/

/*	Semicolons are terminators in the program code, but separators
	(sequentializers) in the AST: if they were terminators in the
	AST, they would always appear together with the '=' sign and be
	superfluous.  We would then need a special binary operator
	"sequentializer" to specify the textual order of the assignment
	statements in the basic block.  So we might as well use the ';',
	which is already there.

	The present code does not use the ';' nodes, since the order
	already follows from the order of the nodes in the array node[].
	But if, in some future modification, the array is replaced by a
	graph, the ';' nodes will be required.
*/

struct node {
	int left;			/* 0 for empty node */
	char operator;
	int right;
	int n_deps;			/* # of explicit dependencies */
	int dep[MAX_DEPS];		/* the explicit dependencies (bag) */
	int n_indeps;			/* # of incoming dependencies */
};

extern int n_nodes;
extern struct node node[MAX_NODES];

extern struct node *new_node(int left, int operator, int right);
extern void new_dep(struct node *nd, int dep);
extern int is_empty_node(const struct node *nd);
extern int is_var_node(const struct node *nd);
extern int node2pos(const struct node *nd);
extern void remove_node(struct node *nd);
extern void remove_unreachable_nodes(void);
