#include	<stdio.h>

#include	"node.h"
#include	"root.h"
#include	"error.h"

int n_roots = 0;
struct root root[MAX_ROOTS];

struct root *
new_root(char var, int index) {
	struct root *rt;

	if (n_roots == MAX_ROOTS) error("input", "too many roots");
	rt = &root[n_roots++];
	
	rt->var = var;
	rt->index = index;
	
	return rt;
}

void
add_root(char var, int index) {
	/* find out if it is already there */
	int i;

	for (i = 0; i < n_roots; i++) {
		struct root *rt = &root[i];
		
		if (rt->var == var && rt->index == index)
			return;
	}

	/* it is a new root */
	new_root(var, index);
	if (index > 0) {
		node[index].n_indeps++;
	}
}
