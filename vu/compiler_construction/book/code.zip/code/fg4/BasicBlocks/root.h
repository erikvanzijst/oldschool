/*	The roots are stored in the array int root[], first as
	1-character variable names form the input, and then, after step 4
	in AST2dep.c, as node indices.
*/

#define		MAX_ROOTS	10

struct root {
	char var;			/* [a-z]: program; [A-Z]: pseudoregs. */
	int index;			/* into node[] */
};

extern int n_roots;
extern struct root root[MAX_ROOTS];
extern struct root *new_root(char var, int index);
extern void add_root(char var, int index);
