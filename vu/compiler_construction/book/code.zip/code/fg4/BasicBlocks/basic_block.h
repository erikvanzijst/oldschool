extern int s_flag;		/* common subexpression elimination */
extern int v_flag;		/* verbose output */
extern int V_flag;		/* detailed output */

