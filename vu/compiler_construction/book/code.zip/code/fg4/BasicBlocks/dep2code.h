extern void dep_graph_to_code(void);
