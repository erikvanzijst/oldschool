extern void error(const char *module, const char *msg);
extern void error2(const char *module, const char *msg, void (*report)(void));
