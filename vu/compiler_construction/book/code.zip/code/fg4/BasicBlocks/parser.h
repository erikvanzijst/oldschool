extern void process_input(void);

