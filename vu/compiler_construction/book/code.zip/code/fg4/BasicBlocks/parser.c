#include	<stdio.h>
#include	<stdlib.h>
#include	<strings.h>

#include	"readtext.h"
#include	"grammar.h"
#include	"precedence.h"
#include	"node.h"
#include	"root.h"
#include	"error.h"

							/* STACK MANIPULATION */

#define	MAX_STACK_SIZE	200

/*	The stack format is operand (operator operand)*.  Operators that
	do not have operands on both sides are given dummy (null) operands.
*/
static int stack[MAX_STACK_SIZE];
static int stack_pointer;

static void
init_stack(void) {
	stack_pointer = 0;
}

static void
push(int item) {
	if (stack_pointer == MAX_STACK_SIZE)
		error("parser", "stack overflow");
	stack[stack_pointer++] = item;
}

static void
pop_entries(int n) {
	stack_pointer -= n;
	if (stack_pointer < 0)
		error("parser", "stack underflow");
}

static int
top_operator(void) {
	if (stack_pointer < 2) error("parser", "stack underflow");
	return stack[stack_pointer-2];
}

static int
second_operator(void) {
	if (stack_pointer < 4) error("parser", "stack underflow");
	return stack[stack_pointer-4];
}

static void
print_stack_item(int i, int operators_only) {
	if (i % 2) {
		/* it is an operator */
		if (stack[i]) {
			printf(" %c", stack[i]);
		}
		else {
			printf(" **NO_OPERATOR**");
		}
	}
	else {	/* it is an operand */
		if (!operators_only) {
			if (stack[i]) {
				printf(" @%d", stack[i]);
			}
			else {
				printf(" 0");
			}
		}
	}
}

static void
print_stack(int operators_only) {
	int i;

	printf("stack size: %d; stack:", stack_pointer);
	for (i = 0; i < stack_pointer; i++) {
		print_stack_item(i, operators_only);
	}
	printf("\n\n");
}

							/* PARSER ACTIONS */

static int dot;

static void
shift(void) {
	push(dot);
	push(0);
	dot = next_token();
}

static void
print_status(void) {
	printf(	"at char number %d, top operator on stack: '%c', looking at '%c'\n",
		char_pos(), top_operator(), dot ? dot : '$');
	print_stack(0);
}

static void
check(const char *name, int opnd) {
	if (opnd == 0) {
		char msg[256];

		sprintf(msg, "missing %s", name);
		error2("syntax", msg, print_status);
	}
}

static int
new_node_index(const char *type_l, int l, int opnd, const char *type_r, int r) {
	const struct node *nd = new_node(l, opnd, r);

	if (type_l) {
		check(type_l, l);
		node[l].n_indeps++;
	}
	if (type_r) {
		check(type_r, r);
		node[r].n_indeps++;
	}

	return nd - &node[0];
}

static void
reduce(void) {
	switch (class_of(top_operator())) {
	case '#':
		/* RHS: 0 '#' assignment '#' 0 (length = 5) */
		check("assignment", stack[stack_pointer-3]);
		stack[stack_pointer-5] = stack[stack_pointer-3];
		pop_entries(4);
		break;

	case '=':
		switch (class_of(second_operator())) {
		case 'A':
			/* RHS: 0 'A' 0 '=' expression (length = 5) */
			stack[stack_pointer-5] =
				new_node_index(
					"expression", stack[stack_pointer-1],
					stack[stack_pointer-2],
					0, stack[stack_pointer-4]
				);
			pop_entries(4);
			break;

		case '*':
			/* RHS: 0 '*' expression '=' expression (length = 5) */
			stack[stack_pointer-5] =
				new_node_index(
					"expression", stack[stack_pointer-1],
					'\\',	/* for =:* */
					"expression", stack[stack_pointer-3]
				);
			pop_entries(4);
			break;

		default:
			error("parser", "unidentified RHS");
			break;
		}
		break;

	case ';':
		/* RHS: assignment ';' assignment (length = 3) */
		stack[stack_pointer-3] =
			new_node_index(
				"assignment", stack[stack_pointer-3],
				stack[stack_pointer-2],
				"assignment", stack[stack_pointer-1]
			);
		pop_entries(2);
		break;

	case '+':
	case '*':
		/* RHS: expression [-+] expression (length = 3) */
		stack[stack_pointer-3] =
			new_node_index(
				"left operand", stack[stack_pointer-3],
				stack[stack_pointer-2],
				"right operand", stack[stack_pointer-1]
			);
		pop_entries(2);
		break;

	case ')':
		/* RHS: 0 '(' expression ')' 0 (length = 5) */
		check("expression", stack[stack_pointer-3]);
		stack[stack_pointer-5] = stack[stack_pointer-3];
		pop_entries(4);
		break;

	case 'A':	/* for LETTER */
	case '0':	/* for DIGIT */
		/* RHS: 0 'letgit' 0 (length = 3) */
		stack[stack_pointer-3] =
			new_node_index(0, stack[stack_pointer-2], 0, 0, 0);
		pop_entries(2);
		break;
		
	default:
		error("parser", "unidentified RHS");
		break;
	}
}

static void
parse_program(void) {
	/* get the text */
	read_text();

	/* initialize the stack */
	init_stack();
	push(0);
	dot = '#';
	shift();

	/* run the precedence parser */
	while (dot) {
		switch (precedence(class_of(top_operator()), class_of(dot))) {
		case '<':
		case '=':
			shift();
			break;
		case '>':
			reduce();
			break;
		case ' ':
			error2("syntax", "no precedence relation", print_status);
			break;
		default:
			error("parser", "unidentified precedence");
			break;
		}
	}

	/* clear the stack */	
	reduce();
}

static void
get_roots(void) {
	read_text();
	while ((dot = next_token()) && dot != '#') {
		if (class_of(dot) != 'A')
			error("input", "root variable is not a variable");
		add_root(dot, 0);
	}
}

void
process_input(void) {
	parse_program();
	get_roots();
}
