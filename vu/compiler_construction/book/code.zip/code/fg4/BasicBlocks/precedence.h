extern char precedence(int t1, int t2);
extern int class_of(int t);
