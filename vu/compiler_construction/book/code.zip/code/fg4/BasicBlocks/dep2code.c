#include	<stdio.h>
#include	<stdlib.h>

#include	"node.h"
#include	"root.h"
#include	"dep2code.h"
#include	"grammar.h"
#include	"basic_block.h"
#include	"error.h"
#include	"print.h"

#define	MAX_LADDER_LENGTH	256
#define FIRST_PSEUDO_REGISTER	'A'
#define	MAX_PSEUDO_REGISTERS	26

#ifdef	lint
#define	UNSORTED_ROOTS
#endif

struct ladder {
	int node[MAX_LADDER_LENGTH];
	int length;
};

							/* PRINT */
static void
print_store_node(const struct node *nd) {
	switch (nd->operator) {
	case '=':
		printf(" %c", nd->right);
		break;
	case '\\':
		printf(" \\");
		break;
	default:
		printf(" *STORE*");
		break;
	}
}

static void
print_ladder_sequence(const struct ladder *ld) {
	int i;

	printf(	"ladder sequence from @%d, length = %d: ",
		ld->node[0], ld->length
	);

	print_store_node(&node[ld->node[0]]);

	/* print the rest */
	for (i = 1; i < ld->length; i++) {
		printf(" %c", node[ld->node[i]].operator);
	}

	printf("\n");
}

							/* STEP 1*/
static void
extend_ladder_sequence(struct ladder *ld, int n, struct ladder *longest) {
	/* ld is an available ladder sequence; try to extend it with node n */
	const struct node *nd = &node[n];

	/* register ld if better than before */
	if (ld->length > longest->length) {
		*longest = *ld;
	}

	if (	/* nd is a leaf */
		nd->operator == 0
	||	/* nd has more than one incoming dependency */
		nd->n_indeps > 1
	) 	/* we cannot extend */ return;

	if (ld->length == MAX_LADDER_LENGTH)
		error("code generation", "ladder too long");
	ld->node[ld->length++] = n;

	/* step 2: */
	extend_ladder_sequence(ld, nd->left, longest);

	/* step 3: */
	if (is_commutative(nd->operator)) {
		extend_ladder_sequence(ld, nd->right, longest);
	}

	ld->length--;
}

static void
find_longest_ladder_sequence(int rt, struct ladder *longest) {
	int first = root[rt].index;
	struct ladder ladder;

	ladder.length = 0;

	/* definition from Subsection 4.2.5: */
	/* step 1: */
	ladder.node[ladder.length++] = first;

	/* steps 2 and 3: */
	longest->length = 0;
	extend_ladder_sequence(&ladder, node[first].left, longest);
	ladder.length--;
}

static void
reverse_sort_roots(void) {
	/* by stupid-sort */
	int done = 0;

	while (!done) {
		int i;

		done = 1;
		for (i = 0; i < n_roots - 1; i++) {
			if (root[i].index < root[i+1].index) {
				/* swap them */
				struct root tmp = root[i];
				root[i] = root[i+1];
				root[i+1] = tmp;
				done = 0;
			}
		}
	}
}

static int
in_ladder(int nd, const struct ladder *ld) {
	/*	This is probably the wrong concept.  What we want to
		know is whether the next step in the ladder goes left or
		right.  However, for the last step the answer is
		"neither", so the result is trivalent, and testing the
		result is a bother.  Also, what are the parameters?
	*/
	int i;

	for (i = 0; i < ld->length; i++) {
		if (ld->node[i] == nd) return 1;
	}
	return 0;
}

								/* STEP 1 */
static void
check_available_ladder_sequence(const struct ladder *ld) {
	int i;

	for (i = 0; i < ld->length; i++) {
		if (node[ld->node[i]].n_indeps != 1)
			error(	"code generation",
				"node in ladder has > 1 incoming dependency"
			);
	}
}

								/* STEP 2 */
static int next_pseudo_register;

static int
new_pseudo_register(void) {
	if (	next_pseudo_register
	==	FIRST_PSEUDO_REGISTER + MAX_PSEUDO_REGISTERS
	)	error("code generation", "too many pseudo-registers");

	return next_pseudo_register++;
}

static int
is_pseudo_register(int r) {
	return	FIRST_PSEUDO_REGISTER <= r
	&&	r < FIRST_PSEUDO_REGISTER + MAX_PSEUDO_REGISTERS
	;
}

struct reg_association {
	int reg;
	int opnd;
};
static struct reg_association reg_association[MAX_PSEUDO_REGISTERS];
static int n_reg_associations;

static void
init_pseudo_registers(void) {
	next_pseudo_register = FIRST_PSEUDO_REGISTER;
	n_reg_associations = 0;
}

static void
associate_reg(int reg, int opnd) {
	struct reg_association *ra = &reg_association[n_reg_associations++];

	ra->reg = reg;
	ra->opnd = opnd;
}

static int
reg_associated_with(int opnd) {
	int i;

	/* look it up in reg_association[] */
	for (i = 0; i < n_reg_associations; i++) {
		struct reg_association *ra = &reg_association[i];

		if (opnd == ra->opnd) return ra->reg;
	}

	return 0;
}

static void
make_operand_into_leaf(int *opnd_p) {
	int opnd = *opnd_p;
	struct node *nd;
	int R;				/* the pseudo-register */

	if (	/* it is already a leaf */
		node[opnd].operator == 0
#ifdef	UNSORTED_ROOTS
	&&	/* it has no other incoming dependencies */
		node[opnd].n_indeps == 1
#endif
	) return;

	R = reg_associated_with(opnd);
	if (R == 0) {
		R = new_pseudo_register();

		/* create the definition node for R, */
		nd = new_node(opnd, '=', R);
		node[opnd].n_indeps++;

		/* register it, */
		associate_reg(R, opnd);

		/* and make it a root */
		add_root(R, node2pos(nd));
	}

	/* create a leaf node for R */
	nd = new_node(R, 0, 0);
	/* and use it as the operand */
	node[opnd].n_indeps--;
	*opnd_p = node2pos(nd);
	nd->n_indeps++;
}

static void
make_all_operands_into_leaves(const struct ladder *ld) {
	int i;

	for (i = 0; i < ld->length; i++) {
		struct node *nd = &node[ld->node[i]];

		if (!in_ladder(nd->left, ld)) {
			make_operand_into_leaf(&nd->left);
		}
		if (nd->operator != '=') {
			if (!in_ladder(nd->right, ld)) {
				make_operand_into_leaf(&nd->right);
			}
		}
	}
}

								/* STEP 3 */
static void
generate_instruction(int optr, int opnd) {
	int actual_opnd = optr == '\\' ? node[opnd].left : opnd;

	printf("%s_%s\t", instr_name(optr), storage_name(actual_opnd));
	printf(is_store_operator(optr) ? "R1,%c" : "%c,R1", actual_opnd);
	printf("\n");
}

static void
generate_code(const struct ladder *ld) {
	int i;

	printf("--------\n");

	if (V_flag) {
		print_ladder_sequence(ld);
		printf("\n");
	}

	/* the instructions are generated in reverse order */
	for (i = 0; i <= ld->length - 1; i++) {
		const struct node *nd = &node[ld->node[i]];
		int opnd = (in_ladder(nd->right, ld) ? nd->left : nd->right);

		if (i == 0) {
			/* the first node stores the pseudo-register */
			generate_instruction(nd->operator, nd->right);
		}

		if (i > 0) {
			/* non-first through last node */
			generate_instruction(nd->operator, node[opnd].left);
		}

		if (i == ld->length-1) {
			/* the last node also loads the pseudo-register */
			opnd = nd->left;
			generate_instruction(0, node[opnd].left);
		}
	}
}

								/* STEP 4 */
static void
remove_root(int n) {
	int i;

	/* remove its dependency */
	node[root[n].index].n_indeps--;

	/* remove it form the root list by shifting the tail */
	for (i = n+1; i < n_roots; i++) {
		root[i-1] = root[i];
	}
	n_roots--;
}

static void
ladder_sequence_to_code(int rt, const struct ladder *ld) {
	/* step 1: already assured by find_longest_ladder_sequence(); check */
	check_available_ladder_sequence(ld);

	/* step 2: */
	make_all_operands_into_leaves(ld);

	/* step 3: */
	generate_code(ld);

	/* step 4: */
	remove_root(rt);
	remove_unreachable_nodes();

	if (V_flag) {
		printf("\n");
		print_graph("one root and ladder removed");
	}
}

								/* DRIVER */
static int
acceptable_root(void) {
	int i;

	/* find the first acceptable root */
	for (i = 0; i < n_roots; i++) {
		struct node *nd = &node[root[i].index];

		/*	a root is not acceptable if some node is still
			dependent on it
		*/
		if (nd->n_indeps != 1) continue;

#ifdef	UNSORTED_ROOTS
		/*	or if it is a pseudo-register for an expression
			on which some node is still dependent (this
			prevents a loop of pseudo-registers being
			redefined as new pseudo-registers)
		*/
		if (	is_pseudo_register(nd->right)
		&&	nd->operator == '='
		&&	node[nd->left].n_indeps != 1
		)	continue;
#endif

		return i;
	}

	error("code generation", "no acceptable root found");
	return 0;
}

void
dep_graph_to_code(void) {
	/*	For code generation, we treat the roots specified in the
		input in reverse AST order, followed by the generated roots.
		We do this by reverse sorting the explicit roots in the
		array root[], and adding the generated roots at the end.

		This is the order the book uses, but the book claims the
		order actually does not matter.  This is not entirely true:
		if the roots are treated in abritrary order,

		1. a node must be made into a register when it is not a leaf
		and/or has more than one incoming dependency (see code in
		make_operand_into_leaf()),

		2. a root is is not acceptable if it consists of a
		pseudo-register associated with an expression with more than
		1 incoming dependency (see code in acceptable_root()),
		
		3. the generated code contains many superfluous register
		movements; this could be reduced by introducing the difference
		between data dependencie and control flow dependencies.
		
		Since there is no inherent merit in doing the roots in
		arbitrary order, the code presented here does them in the
		order suggested in the book.  Code for arbitrary is included
		between UNSORTED_ROOTS ifdefs; when activated, the roots
		are done in the order in which they appear in the second
		segment in the input.
		
		To put more pressure on the algorithm, code could be added
		to do the roots in random order.
	*/

#ifndef	UNSORTED_ROOTS
	reverse_sort_roots();
#endif

#ifdef	lint
	reverse_sort_roots();
#endif

	printf("Code generated in reverse order:\n");

	init_pseudo_registers();
	while (n_roots > 0) {
		/*	The code generation process may generate new roots,
			so a for-loop would not be appropriate.
		*/
		int rt = acceptable_root();
		struct ladder longest_ladder;

		find_longest_ladder_sequence(rt, &longest_ladder);
		ladder_sequence_to_code(rt, &longest_ladder);
	}
	printf("End of code in reverse order.\n");
}
