extern void read_text(void);
extern int next_token(void);
extern int char_pos(void);
