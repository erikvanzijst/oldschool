#include	<stdio.h>
#include	<stdlib.h>

#include	"node.h"
#include	"root.h"
#include	"AST2dep.h"
#include	"error.h"
#include	"basic_block.h"
#include	"print.h"

							/* AUXILIARIES */
static void
add_dep(struct node *nd, int dep) {
	/* should NOT coalesce dependencies */
	new_dep(nd, dep);
	node[dep].n_indeps++;
}

static void
rem_dep(struct node *nd, int dep) {
	/* removes one dependency dep from nd */
	int i;

	for (i = 0; i < nd->n_deps; i++) {
		if (nd->dep[i] == dep) {
			/* one occurrence of dep found; replace by last */
			/* dependency and remove last dependency */
			nd->dep[i] = nd->dep[--nd->n_deps];
			return;
		}
	}
	error("AST2dep", "attempt to remove non-existing dependency");
}

struct def_list {
	int def[MAX_NODES];
	int n_defs;
};

static void
get_definitions_of_var(int pos, int var, struct def_list *dl) {
	/*	yields the node index or indices of the definition(s)
		of var used at index pos, up to and including the first
		(in reverse order) assignment
	*/
	int i;

	dl->n_defs = 0;
	for (i = pos-1; i > 0; i--) {
		const struct node *nd = &node[i];

		if (is_empty_node(nd)) continue;

		if (nd->operator == '=' && nd->right == var) {
			dl->def[dl->n_defs++] = i;
			return;
		}
		if (nd->operator == '\\') {
			dl->def[dl->n_defs++] = i;
		}
	}
}

							/* STEP 2 */
static void
add_vardef_dependency(int pos, int var) {
	int i;
	struct def_list def_list;
	
	get_definitions_of_var(pos, var, &def_list);

	for (i = 0; i < def_list.n_defs; i++) {
		add_dep(&node[pos], def_list.def[i]);
	}
}

static void
add_vardef_dependencies(void) {
	int i;

	/* for all variable uses */
	for (i = n_nodes-1; i > 0; i--) {
		const struct node *nd = &node[i];

		if (is_empty_node(nd)) continue;

		if (is_var_node(nd)) {
			add_vardef_dependency(i, nd->left);
		}
	}
}

							/* STEP 3 */
static void
add_varuse_dependency(int pos, int var) {
	/* node[pos] is a definition of var or an indirect assignment (var=0) */
	int i;

	for (i = pos-1; i > 0; i--) {
		const struct node *nd = &node[i];

		if (is_empty_node(nd)) continue;

		if (!is_var_node(nd)) continue;

		if (nd->left == var || var == 0) {
			add_dep(&node[pos], i);
		}
	}
}

static void
add_varuse_dependencies(void) {
	int i;

	/* for all definitions */
	for (i = n_nodes-1; i > 0; i--) {
		const struct node *nd = &node[i];

		if (is_empty_node(nd)) continue;

		if (nd->operator == '=') {
			/* nd is a definition node */
			add_varuse_dependency(i, nd->right);
		}

		if (nd->operator == '\\') {
			/* nd is an indirect assignment node */
			add_varuse_dependency(i, 0);
		}
	}
}

							/* STEP 4 */
static void
designate_var_root(int i) {
	/* set root[i].index to the last definition of root[i].var */
	int var = root[i].var;
	int j;

	for (j = i-1; j >= 0; j--) {
		if (root[j].var == var)
			error("input", "duplicate root variable");
	}

	for (j = n_nodes-1; j > 0; j--) {
		struct node *nd = &node[j];

		if (is_empty_node(nd)) continue;

		if (nd->operator == '=' && nd->right == var) {
			/* found the assignment to var */
			root[i].index = j;
			nd->n_indeps++;
			return;
		}
	}

	error("input", "root variable without assignment");
}

static void
designate_assignment_root(int i) {
	struct node *nd = &node[i];

	if (is_empty_node(nd)) return;

	if (nd->operator == '\\') {
		/* nd is an indirect assignment node */
		add_root('\\', i);
	}
}

static void
designate_roots(void) {
	int i;

	/* roots deriving from live variables in root[] */
	for (i = 0; i < n_roots; i++) {
		designate_var_root(i);
	}

	/* roots deriving from indirect assignments in node[] */
	for (i = 0; i < n_nodes; i++) {
		designate_assignment_root(i);
	}
}

							/* STEP 5 */
static void
remove_semicolons(void) {
	int i;

	for (i = n_nodes-1; i > 0; i--) {
		struct node *nd = &node[i];

		if (is_empty_node(nd)) continue;

		if (nd->operator == ';') {
			remove_node(nd);
		}
	}
}

							/* STEP 6 */
static void
copy_dependencies(const struct node *old, struct node *new) {
	int i;

	for (i = 0; i < old->n_deps; i++) {
		add_dep(new, old->dep[i]);
	}
}

static void
short_circuit_assignment(int pos, int var) {
	struct def_list def_list;
	
	get_definitions_of_var(pos, var, &def_list);
	
	if (def_list.n_defs == 0) return;
	
	if (node[def_list.def[0]].operator == '=') {
		/* there is an unobscured assignment */
		int def = def_list.def[0];
		struct node *def_node = &node[def];
		struct node *var_node = &node[pos];
		int source = def_node->left;

		/*	Pull the source value towards the variable.  This
			involves converting a value node (v, 0, 0) into a
			definition node (@N, =, v).
		*/
		def_node->n_indeps--;
		rem_dep(var_node, def);
		var_node->right = var_node->left;	/* move variable */
		var_node->left = source;
		node[source].n_indeps++;
		var_node->operator = '=';

		/* copy the dependencies of the definition to the variable */
		copy_dependencies(def_node, var_node);
	}
	else {
		/*	If a definition exists, it was obscured by an
			indirect assignment. In that case it must be made a
			root if it wasn't one already.
		*/
		int last_def = def_list.def[def_list.n_defs-1];

		/* if last_def is an assignment: */
		if (node[last_def].operator == '=') {
			add_root(var, last_def);
		}
	}
}

static void
short_circuit_assignments(void) {
	int i;

	/* for all variable uses */
	for (i = n_nodes-1; i > 0; i--) {
		const struct node *nd = &node[i];

		if (is_empty_node(nd)) continue;

		if (is_var_node(nd)) {
			/* now nd is: v */
			short_circuit_assignment(i, nd->left);
		}
	}
}

							/* STEP 7 */
static void short_circuit_operand(struct node *nd, int *opnd_p);

static void
short_circuit_variable(struct node *nd, int *opnd_p) {
	/* we now know that *opnd_p is the address of a var definition node */
	struct node *def_node = &node[*opnd_p];
	int source; /* not yet known; def_node may point to another def_node */

	/* treat def_node's left operand recursively */
	short_circuit_operand(def_node, &def_node->left);

	source = def_node->left;	/* now we know */

	/* pull the vardef value (source) towards the operand */
	def_node->n_indeps--;
	*opnd_p = source;
	node[source].n_indeps++;

	/* copy the dependencies of the definition to the variable */
	copy_dependencies(def_node, nd);
}

static void
short_circuit_operand(struct node *nd, int *opnd_p) {
	/* opnd_p must be the index of a node */
	if (*opnd_p >= n_nodes || is_empty_node(&node[*opnd_p]))
		error("AST2dep", "updating non-existing node");

	/* first see if there is a variable definition node ahead */
	/* otherwise there is nothing to short-circuit */
	if (node[*opnd_p].operator == '=') {
		short_circuit_variable(nd, opnd_p);
	}
}

static void
short_circuit_variables(void) {
	int i;

	/* for all operands */
	for (i = n_nodes-1; i > 0; i--) {
		struct node *nd = &node[i];
		int j;

		if (is_empty_node(nd)) continue;

		if (nd-> operator != 0) {
			/* short-circuit the operands */
			/* now nd is: @N = v | @N \ @M | @N optr @N */
			short_circuit_operand(nd, &nd->left);
			if (nd->operator != '=') {
				/* now nd is: @N \ @M | @N optr @N */
				short_circuit_operand(nd, &nd->right);
			}
		}

		/* short-circuit the dependencies */
		for (j = 0; j < nd->n_deps; j++) {
			short_circuit_operand(nd, &nd->dep[j]);
		}
	}
}

							/* STEP 8 */
static int
earliest_copy_of_node(int n) {
	const struct node *nd = &node[n];
	int res = 0;
	int i;

	for (i = n-1; i > 0; i--) {
		const struct node *nd1 = &node[i];

		if (is_empty_node(nd1)) continue;

		if (	nd->left == nd1->left
		&&	nd->operator == nd1->operator
		&&	nd->right == nd1->right
		) {
			res = i;
		}
	}
	return res;
}

static void
short_circuit_node_field(int *fld, int old, int new) {
	/*	In field *fld, replace a possible reference to node old by
		a reference to node new.
	*/
	if (*fld == old) {
		*fld = new;
		node[old].n_indeps--;
		node[new].n_indeps++;
	}
}

static void
short_circuit_node(struct node *nd, int old, int new) {
	/*	In node nd, replace all references to node old by
		references to node new.
	*/
	int i;

	if (nd->operator) {
		/* short-circuit the operands */
		/* now nd is: @N = v | @N \ @M | @N optr @N */
		short_circuit_node_field(&nd->left, old, new);
		if (nd->operator != '=') {
			/* now nd is: @N \ @M | @N optr @N */
			short_circuit_node_field(&nd->right, old, new);
		}
	}

	/* short-circuit the dependencies */
	for (i = 0; i < nd->n_deps; i++) {
		short_circuit_node_field(&nd->dep[i], old, new);
	}
}

static void
short_circuit_nodes(int old, int new) {
	/*	Replace all references to node old by references to node new,
		in all nodes beyond old.
	*/
	int i;

	for (i = old+1; i < n_nodes; i++) {
		struct node *nd = &node[i];

		if (is_empty_node(nd)) continue;

		short_circuit_node(nd, old, new);
	}

	/* now old should have no incoming dependencies any more */
	if (node[old].n_indeps != 0)
		error("AST2dep", "CSE: left-over incoming dependencies");

	/* copy the dependencies of old to new */
	copy_dependencies(&node[old], &node[new]);
}

static void
eliminate_common_subexpressions(void) {
	/*	Since the nodes are in depth-first order, we can just
		remove all duplicate nodes, from top to bottom.
	*/
	int i;

	for (i = 1; i < n_nodes; i++) {
		const struct node *nd = &node[i];
		int j;

		if (is_empty_node(nd)) continue;

		j = earliest_copy_of_node(i);
		if (j) {
			short_circuit_nodes(i, j);
		}
	}
}

							/* DRIVER */
void
AST_to_dep_graph(void) {
	/* algorithm in Subsection 4.2.5: */

	/* step 2: */
	add_vardef_dependencies();
	if (V_flag) print_graph("After step 2 - var def deps added");

	/* step 3: */
	add_varuse_dependencies();
	if (V_flag) print_graph("After step 3 - var use deps added");

	/* step 4: */
	designate_roots();
	if (V_flag) print_graph("After step 4 - roots designated");

	/* step 5: */
	remove_semicolons();
	if (V_flag) print_graph("After step 5 - semicolons removed");

	/* step 6: */
	short_circuit_assignments();
	if (V_flag) print_graph("assignments shorted, unclean");
	remove_unreachable_nodes();
	if (V_flag) print_graph("assignments shorted, cleaned");

	/* step 7: */
	short_circuit_variables();
	if (V_flag) print_graph("variables shorted, unclean");
	remove_unreachable_nodes();
	if (V_flag) print_graph("variables shorted, cleaned");

	/* step 8: */
	if (s_flag) {
		eliminate_common_subexpressions();
		if (V_flag) print_graph("common subexpressions eliminated, unclean");
		remove_unreachable_nodes();
		if (V_flag) print_graph("common subexpressions eliminated, cleaned");
	}
}
