#include	<stdio.h>
#include	<ctype.h>

#include	"node.h"
#include	"error.h"

int n_nodes = 1;			/* leave 0 as NULL */
struct node node[MAX_NODES];

struct node *
new_node(int left, int operator, int right) {
	struct node *nd;

	if (n_nodes == MAX_NODES) error("input", "too many nodes");
	nd = &node[n_nodes++];
	
	nd->left = left;
	nd->operator = operator;
	nd->right = right;
	nd->n_deps = 0;
	nd->n_indeps = 0;
	
	return nd;
}

void
new_dep(struct node *nd, int dep) {
	if (nd->n_deps == MAX_DEPS) error("input", "too many dependencies");
	(nd->dep)[nd->n_deps++] = dep;
}

int
is_empty_node(const struct node *nd) {
	return nd->left == 0;
}

int
is_var_node(const struct node *nd) {
	return nd->operator == 0 && isalpha(nd->left);
}

int
node2pos(const struct node *nd) {
	return nd - &node[0];
}

void
remove_node(struct node *nd) {
	int j;

	/* remove implicit dependencies */
	if (nd->operator) {

		/* nd is: @N = v | @N optr @N */
		node[nd->left].n_indeps--;
		if (nd->operator != '=') {
			/* nd is: @N optr @N */
			node[nd->right].n_indeps--;
		}
	}

	/* remove explicit dependencies */
	for (j = 0; j < nd->n_deps; j++) {
		node[nd->dep[j]].n_indeps--;
	}

	/* clear the node */
	nd->left = 0;
}

void
remove_unreachable_nodes(void) {
	int done = 0;
	
	while (!done) {
		int i;
	
		done = 1;
		for (i = n_nodes-1; i > 0; i--) {
			struct node *nd = &node[i];
	
			if (is_empty_node(nd)) continue;/* already removed */
	
			if (nd->n_indeps == 0) {
				/* nd is unreachable */
				remove_node(nd);
				done = 0;
			}
		}
	}
}
