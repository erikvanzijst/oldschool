int stack[100];
int sp = 0;
