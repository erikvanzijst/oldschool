extern AST_node *Thread_start;
extern void Thread_AST(AST_node *);
