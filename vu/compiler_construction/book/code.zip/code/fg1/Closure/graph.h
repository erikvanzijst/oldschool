struct graph {
    int gr_size;
    struct g_node *first, **hook;       /* linked list of graph nodes */
};

struct g_node {
    struct g_node *next;
    int gn_number;                      /* node identification */
    enum {new, done} gn_status;
    struct g_link *first, **hook;       /* linked list of node pointers */
};

struct g_link {
    struct g_link *next;
    struct g_node *gl_node;
};

extern struct graph *new_graph(void);
extern struct g_node *add_node(struct graph *graph);

extern struct graph *read_graph(FILE *ifile);
extern void print_graph(struct graph *graph);

extern int arrow_exists(struct g_node *from, struct g_node *to);
extern void add_arrow(struct g_node *from, struct g_node *to);
