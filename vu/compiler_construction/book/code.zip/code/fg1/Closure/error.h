extern void error(char *fmt, int i);
