#include    <stdio.h>
#include    <stdlib.h>
#include    <malloc.h>

#include    "graph.h"
#include    "error.h"

/* macros for appending elements at the end of linked lists */
#define    init_for_append(x)    (x)->hook = &(x)->first
#define    append(x,y)    ((y)->next = *(x)->hook, *(x)->hook = (y), (x)->hook = &(y)->next)

/* macros for prepending elements at the start of linked lists */
#define    init_for_prepend(x)
#define    prepend(x,y)    ((y)->next = (x)->first, (x)->first = (y))

void *
Calloc(size_t n, size_t s) {
    void *mem = calloc(n, s);

    if (mem == 0) {
        fprintf(stderr, "Out of memory\n");
        exit(1);
    }
    return mem;
}

struct graph *
new_graph(void) {
    struct graph *graph =
        (struct graph *)Calloc(1, sizeof (struct graph));

    init_for_append(graph);
    return graph;
}

struct g_node *
add_node(struct graph *graph) {
    struct g_node *g_node =
        (struct g_node *)Calloc(1, sizeof(struct g_node));

    init_for_append(g_node);

    graph->gr_size++;
    append(graph, g_node);
    return g_node;
}

struct graph *
read_graph(FILE *ifile) {
    struct graph *graph = new_graph();
    int size;
    struct g_node **spine;
    int pos;

    if (fscanf(ifile, "%d", &size) != 1) {
        error("graph size missing in input", 0);
        exit(1);
    }

    /* construct the linked list of g_nodes */
    spine = (struct g_node **)Calloc(size+1, sizeof (struct g_node *));
    for (pos = 1; pos <= size; pos++) {
        struct g_node *g_node = add_node(graph);

        g_node->gn_number = pos;
        spine[pos] = g_node;
    }

    /* construct the graph */
    while (fscanf(ifile, "%d:", &pos) == 1) {
        struct g_node *g_node;
        int node_nmb;

        if (!(1 <= pos && pos <= size)) {
            error("node number %d out of range in input", pos);
            exit(1);
        }
        g_node = spine[pos];

        /* process one node's connections */
        while (
            fscanf(ifile, "%d", &node_nmb) == 1
        &&  node_nmb != 0
        ) {
            if (!(1 <= node_nmb && node_nmb <= size)) {
                error("node number %d out of range in input", node_nmb);
                exit(1);
            }
            add_arrow(g_node, spine[node_nmb]);
        }
    }

    free((char *)spine);
    return graph;
}

int
arrow_exists(struct g_node *from, struct g_node *to) {
    struct g_link *g_link;

    for (g_link = from->first; g_link; g_link = g_link->next) {
        if (g_link->gl_node == to) return 1;
    }
    return 0;
}

void
add_arrow(struct g_node *from, struct g_node *to) {
    if (!arrow_exists(from, to)) {
        struct g_link *g_link =
            (struct g_link *)Calloc(1, sizeof (struct g_link));

        g_link->gl_node = to;
        append(from, g_link);
    }
}

void
print_graph(struct graph *graph) {
    /* reproduces the read_graph format */
    struct g_node *np;

    printf("%d\n", graph->gr_size);

    for (np = graph->first; np; np = np->next) {
        struct g_link *lp;

        printf("%d: ", np->gn_number);
        for (lp = np->first; lp; lp = lp->next) {
            printf("%d ", lp->gl_node->gn_number);
        }
        printf("0\n");
    }
}
