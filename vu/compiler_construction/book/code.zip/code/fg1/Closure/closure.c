#include    <stdio.h>
#include    <stdlib.h>

#include    "graph.h"
#include    "error.h"

                                                        /* DRIVER */
static void closure_TD(struct graph *graph);
static void closure_BU(struct graph *graph);

static int action_count;

int
main(int argc, char *argv[]) {
    struct graph *graph;
    FILE *ifile = (argc < 2 ? stdin : fopen(argv[1], "r"));

    if (ifile == stdin) {
        error("the present version cannot do standard input", 0);
        exit(1);
    }
    if (!ifile) {
        error("cannot open input file", 0);
        exit(1);
    }
    fclose(ifile);

    printf("Top-down closure computation:\n");
    ifile = fopen(argv[1], "r");
    graph = read_graph(ifile);
    action_count = 0;
    closure_TD(graph);
    printf("action_count = %d\n", action_count);
    print_graph(graph);
    fclose(ifile);

    printf("Bottom-up closure computation:\n");
    ifile = fopen(argv[1], "r");
    graph = read_graph(ifile);
    action_count = 0;
    closure_BU(graph);
    printf("action_count = %d\n", action_count);
    print_graph(graph);
    fclose(ifile);

    return 0;
}

                                                        /* TOP-DOWN */
static void closure_single_node(struct g_node *node);

static void
closure_TD(struct graph *graph) {
    struct g_node *node;

    /* all nodes node in graph are new */
    for (node = graph->first; node; node = node->next) {
        node->gn_status = new;
    }

    for (node = graph->first; node; node = node->next) {
        struct g_node *n;

        /* compute all descendants of node */
        closure_single_node(node);

        /* all its descendants are new */
        for (n = node->next; n; n = n->next) {
            n->gn_status = new;
        }
        /* but the node itself is done */
        node->gn_status = done;
    }
}

static void
closure_single_node(struct g_node *node1) {
    struct g_link *lp2;

    if (node1->gn_status == done) return;

    node1->gn_status = done;

    /* for all node1's direct descendants node2 */
    for (lp2 = node1->first; lp2; lp2 = lp2->next) {
        struct g_node *node2 = lp2->gl_node;
        struct g_link *lp3;

        /* compute all descendants of node2 */
        closure_single_node(node2);

        /* for all node2's descendants node3 */
        for (lp3 = node2->first; lp3; lp3 = lp3->next) {
            struct g_node *node3 = lp3->gl_node;

            action_count++;
            if (!arrow_exists(node1, node3)) {
                add_arrow(node1, node3);
            }
        }
    }
}

                                                        /* BOTTOM-UP */
static void
closure_BU(struct graph *graph) {
    int something_changed = 1;

    while (something_changed) {
        struct g_node *node1;
        something_changed = 0;

        /* for all nodes node1 in graph */
        for (node1 = graph->first; node1; node1 = node1->next) {
            struct g_link *lp2;

            /* for all node1's descendants node2 */
            for (lp2 = node1->first; lp2; lp2 = lp2->next) {
                struct g_node *node2 = lp2->gl_node;
                struct g_link *lp3;

                /* for all node2's descendants node3 */
                for (lp3 = node2->first; lp3; lp3 = lp3->next) {
                    struct g_node *node3 = lp3->gl_node;

                    action_count++;
                    if (!arrow_exists(node1, node3)) {
                        add_arrow(node1, node3);
                        something_changed = 1;
                    }
                }
            }
        }
    }
}
