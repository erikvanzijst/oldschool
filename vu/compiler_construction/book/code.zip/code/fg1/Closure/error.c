#include    <stdio.h>

#include    "error.h"

void
error(char *fmt, int i) {
    fprintf(stderr, "Error in closure: ");
    fprintf(stderr, fmt, i);
    fprintf(stderr, "\n");
}
