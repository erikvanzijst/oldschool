class Demo_Compiler {
    public static void main(String[] args) {
        // Get the intermediate code
        Lex.Get_Token();            // start the lexical analyser
        Expression icode = Expression.Parse_Or();
        if (Lex.Token_Class != Lex.EOF) {
            System.err.println("Garbage at end of program ignored");
        }
        if (icode == null) {
            System.err.println("No intermediate code produced");
            return;
        }

        // Print it
        System.out.print("Expression: ");
        icode.Print();
        System.out.println();

        // Interpret it
        System.out.print("Interpreted: ");
        System.out.println(icode.Interpret());

        // Generate code for it
        System.out.println("Code:");
        icode.Generate_Code();
        System.out.println("PRINT");
    }
}
