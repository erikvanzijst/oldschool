abstract class Operator {
    public static Operator Parse_Or() {
        // Try to parse a '+'
        Actual_Operator co_plus = new Actual_Operator('+');
        if (co_plus.Parse_And()) return co_plus;

        // Try to parse a '*'
        Actual_Operator co_times = new Actual_Operator('*');
        if (co_times.Parse_And()) return co_times;

        return null;
    }

    abstract public void Print();
    abstract public int Interpret(int e_left, int e_right);
    abstract public void Generate_Code();
}

class Actual_Operator extends Operator {
    private char oper;

    public Actual_Operator(char op) {oper = op;}

    public boolean Parse_And() {
        if (Lex.Token_Class == oper) {Lex.Get_Token(); return true;}
        return false;
    }

    public void Print() {System.out.print(oper);}

    public int Interpret(int e_left, int e_right) {
        switch (oper) {
        case '+': return e_left + e_right;
        case '*': return e_left * e_right;
        }
        return 0;
    }

    public void Generate_Code() {
        switch (oper) {
        case '+': System.out.print("ADD\n"); break;
        case '*': System.out.print("MULT\n"); break;
        }
    }
}
