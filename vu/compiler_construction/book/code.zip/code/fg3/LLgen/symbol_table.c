#include    <malloc.h>

#include    "symbol_table.h"

void
init_symbol_table(symbol_table *sym_tab_p) {
    *sym_tab_p =
        (symbol_entry *)calloc(26, sizeof (symbol_entry));
}

symbol_entry *
look_up(symbol_table sym_tab, char repr) {
    return &sym_tab[repr - 'a'];
}

