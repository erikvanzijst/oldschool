typedef struct {
    char *name;
    int value;
} symbol_entry;

typedef symbol_entry *symbol_table;

extern void init_symbol_table(symbol_table *sym_tab_p);
extern symbol_entry *look_up(
    symbol_table sym_tab, char repr
);
