extern void visit_1_Number(struct Number *Number);
