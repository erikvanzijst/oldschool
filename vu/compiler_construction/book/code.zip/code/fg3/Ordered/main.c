#include    <stdio.h>

#include    "tree.h"
#include    "visit.h"

int
main(int argc, char *argv[]) {
    struct Number *Number;

    while (argc > 1 && argv[1][0] == '-') {
        switch (argv[1][1]) {
        }
        argc--, argv++;
    }

    /* construct a test tree */
    Number =
        create_Number_1(
            create_DigitSeq_1(
                create_DigitSeq_1(
                    create_DigitSeq_2(
                        create_Digit_1(create_Token('5'))
                    ),
                    create_Digit_1(create_Token('6'))
                ),
                create_Digit_1(create_Token('7'))
            ),
            create_BaseTag_1()
        );

    /* run the ordered visits */
    visit_1_Number(Number);

    /* print one attribute */
    printf("Number.value = %d\n", Number->value);

    return 0;
}
