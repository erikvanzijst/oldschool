#include    <stdio.h>

#include    "tree.h"
#include    "visit.h"

static void visit_1_DigitSeq(struct DigitSeq *DigitSeq);

/*                                                              BaseTag */

static void
visit_1_BaseTag_1(struct BaseTag *BaseTag, struct BaseTag_1 *BaseTag_1) {
/* Visit 1 from the parent: flow of control from the parent enters here */
/* The parent has set the attributes in IN[0] of BaseTag, the set { } */

    /* Visit some children: */

    /* End of the visits to children */

    /* Compute the attributes in SN[0] of BaseTag, the set { base } */
    BaseTag->base = 8;

    /* Leave to the parent */
    return;
}

static void
visit_1_BaseTag_2(struct BaseTag *BaseTag, struct BaseTag_2 *BaseTag_2) {
/* Visit 1 from the parent: flow of control from the parent enters here */
/* The parent has set the attributes in IN[0] of BaseTag, the set { } */

    /* Visit some children: */

    /* End of the visits to children */

    /* Compute the attributes in SN[0] of BaseTag, the set { base } */
    BaseTag->base = 10;

    /* Leave to the parent */
    return;
}

static void
visit_1_BaseTag(struct BaseTag *BaseTag) {
    if (BaseTag->alt_number == 1) {
        visit_1_BaseTag_1(BaseTag, &BaseTag->alternatives.BaseTag_1);
    }
    if (BaseTag->alt_number == 2) {
        visit_1_BaseTag_2(BaseTag, &BaseTag->alternatives.BaseTag_2);
    }
}

/*                                                              Digit */

static void
visit_1_Digit_1(struct Digit *Digit, struct Digit_1 *Digit_1) {
/* Visit 1 from the parent: flow of control from the parent enters here */
/* The parent has set the attributes in IN[0] of Digit, the set { base } */

    /* Visit some children: */

    /* End of the visits to children */

    /* Compute the attributes in SN[0] of Digit, the set { value } */
    int token_value = Digit_1->Token->repr - '0';

    if (token_value < Digit->base) {
        Digit->value = token_value;
    }
    else {
        Digit->value = Digit->base - 1;
        printf("Token %c cannot be a digit in base %d\n",
            Digit_1->Token->repr, Digit->base
        );
    }

    /* Leave to the parent */
    return;
}

static void
visit_1_Digit(struct Digit *Digit) {
    if (Digit->alt_number == 1) {
        visit_1_Digit_1(Digit, &Digit->alternatives.Digit_1);
    }
}

/*                                                              DigitSeq */

static void
visit_1_DigitSeq_1(struct DigitSeq *DigitSeq, struct DigitSeq_1 *DigitSeq_1) {
/* Visit 1 from the parent: flow of control from the parent enters here */
/* The parent has set the attributes in IN[0] of DigitSeq, the set { base } */

    /* Visit some children: */

    /* Compute the attributes in IN[0] of DigitSeq(), the set { base } */
    DigitSeq_1->DigitSeq->base = DigitSeq->base;
    /* Visit DigitSeq for the first time */
    visit_1_DigitSeq(DigitSeq_1->DigitSeq);
    /* DigitSeq returns with its SN[0], the set { value }, evaluated */

    /* Compute the attributes in IN[0] of Digit(), the set { base } */
    DigitSeq_1->Digit->base = DigitSeq->base;
    /* Visit Digit for the first time */
    visit_1_Digit(DigitSeq_1->Digit);
    /* Digit returns with its SN[0], the set { value }, evaluated */

    /* End of the visits to children */

    /* Compute the attributes in SN[0] of DigitSeq, the set { value } */
    DigitSeq->value = DigitSeq_1->DigitSeq->value * DigitSeq->base +
        DigitSeq_1->Digit->value;

    /* Leave to the parent */
    return;
}

static void
visit_1_DigitSeq_2(struct DigitSeq *DigitSeq, struct DigitSeq_2 *DigitSeq_2) {
/* Visit 1 from the parent: flow of control from the parent enters here */
/* The parent has set the attributes in IN[0] of DigitSeq, the set { base } */

    /* Visit some children: */

    /* Compute the attributes in IN[0] of Digit(), the set { base } */
    DigitSeq_2->Digit->base = DigitSeq->base;
    /* Visit Digit for the first time */
    visit_1_Digit(DigitSeq_2->Digit);
    /* Digit returns with its SN[0], the set { value }, evaluated */

    /* End of the visits to children */

    /* Compute the attributes in SN[0] of DigitSeq, the set { value } */
    DigitSeq->value = DigitSeq_2->Digit->value;

    /* Leave to the parent */
    return;
}

static void
visit_1_DigitSeq(struct DigitSeq *DigitSeq) {
    if (DigitSeq->alt_number == 1) {
        visit_1_DigitSeq_1(DigitSeq, &DigitSeq->alternatives.DigitSeq_1);
    }
    if (DigitSeq->alt_number == 2) {
        visit_1_DigitSeq_2(DigitSeq, &DigitSeq->alternatives.DigitSeq_2);
    }
}

/*                                                              Number */

static void
visit_1_Number_1(struct Number *Number, struct Number_1 *Number_1) {
/* Visit 1 from the parent: flow of control from the parent enters here */
/* The parent has set the attributes in IN[0] of Number, the set { } */

    /* Visit some children: */

    /* Compute the attributes in IN[0] of BaseTag(), the set {} */
    /* Visit BaseTag for the first time */
    visit_1_BaseTag(Number_1->BaseTag);
    /* BaseTag returns with its SN[0], the set { base }, evaluated */

    /* Compute the attributes in IN[0] of DigitSeq(), the set { base } */
    Number_1->DigitSeq->base = Number_1->BaseTag->base;
    /* Visit DigitSeq for the first time */
    visit_1_DigitSeq(Number_1->DigitSeq);
    /* DigitSeq returns with its SN[0], the set { value }, evaluated */

    /* End of the visits to children */

    /* Compute the attributes in SN[0] of Number, the set { value } */
    Number->value = Number_1->DigitSeq->value;

    /* Leave to the parent */
    return;
}

void
visit_1_Number(struct Number *Number) {
    if (Number->alt_number == 1) {
        visit_1_Number_1(Number, &Number->alternatives.Number_1);
    }
}
