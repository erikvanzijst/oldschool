/* Integer attribute type */

typedef int int_attribute;
