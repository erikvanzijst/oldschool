/* Integer attribute type */

typedef struct {
    int ia_set;             /* flag "computed" */
    int ia_value;           /* value when computed */
} int_attribute;
#define     is_set(a)       ((a).ia_set)
#define     set(a,v)        ((a).ia_set = 1, (a).ia_value = v)
#define     val(a)          ((a).ia_value)
