#include    <malloc.h>

#include    "attrtype.h"

#define     new_node(Type)  ((Type *)calloc(1, sizeof(Type)))

/* Node types */

struct Number {
    int alt_number;
    int_attribute value;
    union {
        struct Number_1 {
            struct DigitSeq *DigitSeq;
            struct BaseTag *BaseTag;
        } Number_1;
    } alternatives;
};

struct DigitSeq {
    int alt_number;
    int_attribute base;
    int_attribute value;
    union {
        struct DigitSeq_1 {
            struct DigitSeq *DigitSeq;
            struct Digit *Digit;
        } DigitSeq_1;
        struct DigitSeq_2 {
            struct Digit *Digit;
        } DigitSeq_2;
    } alternatives;
};

struct Digit {
    int alt_number;
    int_attribute base;
    int_attribute value;
    union {
        struct Digit_1 {
            struct Token *Token;
        } Digit_1;
    } alternatives;
};

struct BaseTag {
    int alt_number;
    int_attribute base;
    union {
        struct BaseTag_1 {
            int dummy;      /* required by C */
        } BaseTag_1;
        struct BaseTag_2 {
            int dummy;      /* required by C */
        } BaseTag_2;
    } alternatives;
};

struct Token {
    int class;
    int repr;
};

extern struct Number *create_Number_1(struct DigitSeq *DigitSeq, struct BaseTag *BaseTag);
extern struct DigitSeq *create_DigitSeq_1(struct DigitSeq *DigitSeq, struct Digit *Digit);
extern struct DigitSeq *create_DigitSeq_2(struct Digit *Digit);
extern struct Digit *create_Digit_1(struct Token *Token);
extern struct BaseTag *create_BaseTag_1(void);
extern struct BaseTag *create_BaseTag_2(void);
extern struct Token *create_Token(char ch);
