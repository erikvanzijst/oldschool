/* one possible implementation of the dataflow machine */

#include    <stdio.h>

#include    "main.h"
#include    "tree.h"
#include    "eval.h"

static void eval_DigitSeq(struct DigitSeq *DigitSeq);

static void
propagate_BaseTag_1(struct BaseTag *BaseTag, struct BaseTag_1 *BaseTag_1) {
    if (!is_set(BaseTag->base)
    ) {
        set(BaseTag->base, 8);
    }
}

static void
eval_BaseTag_1(struct BaseTag *BaseTag, struct BaseTag_1 *BaseTag_1) {
    /* propagate attributes */
    if (pre_call) {
        propagate_BaseTag_1(BaseTag, BaseTag_1);
    }

    /* traverse subtrees */

    /* propagate attributes */
    if (post_call) {
        propagate_BaseTag_1(BaseTag, BaseTag_1);
    }
}

static void
propagate_BaseTag_2(struct BaseTag *BaseTag, struct BaseTag_2 *BaseTag_2) {
    if (!is_set(BaseTag->base)
    ) {
        set(BaseTag->base, 10);
    }
}

static void
eval_BaseTag_2(struct BaseTag *BaseTag, struct BaseTag_2 *BaseTag_2) {
    /* propagate attributes */
    if (pre_call) {
        propagate_BaseTag_2(BaseTag, BaseTag_2);
    }

    /* traverse subtrees */

    /* propagate attributes */
    if (post_call) {
        propagate_BaseTag_2(BaseTag, BaseTag_2);
    }
}

static void
eval_BaseTag(struct BaseTag *BaseTag) {
    if (BaseTag->alt_number == 1) {
        eval_BaseTag_1(BaseTag, &BaseTag->alternatives.BaseTag_1);
    }
    if (BaseTag->alt_number == 2) {
        eval_BaseTag_2(BaseTag, &BaseTag->alternatives.BaseTag_2);
    }
}

static void
propagate_Digit_1(struct Digit *Digit, struct Digit_1 *Digit_1) {
    if (!is_set(Digit->value)
    &&  is_set(Digit->base)
    ) {
        int token_value = Digit_1->Token->repr - '0';

        if (token_value < val(Digit->base)) {
            set(Digit->value, token_value);
        }
        else {
            set(Digit->value, val(Digit->base) - 1);
            printf("Token %c cannot be a digit in base %d\n",
                Digit_1->Token->repr, val(Digit->base)
            );
        }
    }
}

static void
eval_Digit_1(struct Digit *Digit, struct Digit_1 *Digit_1) {
    /* propagate attributes */
    if (pre_call) {
        propagate_Digit_1(Digit, Digit_1);
    }

    /* traverse subtrees */

    /* propagate attributes */
    if (post_call) {
        propagate_Digit_1(Digit, Digit_1);
    }
}

static void
eval_Digit(struct Digit *Digit) {
    if (Digit->alt_number == 1) {
        eval_Digit_1(Digit, &Digit->alternatives.Digit_1);
    }
}

static void
propagate_DigitSeq_1(struct DigitSeq *DigitSeq, struct DigitSeq_1 *DigitSeq_1) {
    if (!is_set(DigitSeq_1->DigitSeq->base)
    &&  is_set(DigitSeq->base)
    ) {
        set(DigitSeq_1->DigitSeq->base, val(DigitSeq->base));
    }

    if (!is_set(DigitSeq_1->Digit->base)
    &&  is_set(DigitSeq->base)
    ) {
        set(DigitSeq_1->Digit->base, val(DigitSeq->base));
    }

    if (!is_set(DigitSeq->value)
    &&  is_set(DigitSeq_1->DigitSeq->value)
    &&  is_set(DigitSeq->base)
    &&  is_set(DigitSeq_1->Digit->value)
    ) {
        set(DigitSeq->value,
            val(DigitSeq_1->DigitSeq->value) *
            val(DigitSeq->base) +
            val(DigitSeq_1->Digit->value)
        );
    }
}

static void
eval_DigitSeq_1(struct DigitSeq *DigitSeq, struct DigitSeq_1 *DigitSeq_1) {
    /* propagate attributes */
    if (pre_call) {
        propagate_DigitSeq_1(DigitSeq, DigitSeq_1);
    }

    /* traverse subtrees */
    eval_DigitSeq(DigitSeq_1->DigitSeq);
    eval_Digit(DigitSeq_1->Digit);

    /* propagate attributes */
    if (post_call) {
        propagate_DigitSeq_1(DigitSeq, DigitSeq_1);
    }
}

static void
propagate_DigitSeq_2(struct DigitSeq *DigitSeq, struct DigitSeq_2 *DigitSeq_2) {
    if (!is_set(DigitSeq_2->Digit->base)
    &&  is_set(DigitSeq->base)
    ) {
        set(DigitSeq_2->Digit->base, val(DigitSeq->base));
    }

    if (!is_set(DigitSeq->value)
    &&  is_set(DigitSeq_2->Digit->value)
    ) {
        set(DigitSeq->value, val(DigitSeq_2->Digit->value));
    }
}

static void
eval_DigitSeq_2(struct DigitSeq *DigitSeq, struct DigitSeq_2 *DigitSeq_2) {
    /* propagate attributes */
    if (pre_call) {
        propagate_DigitSeq_2(DigitSeq, DigitSeq_2);
    }

    /* traverse subtrees */
    eval_Digit(DigitSeq_2->Digit);

    /* propagate attributes */
    if (post_call) {
        propagate_DigitSeq_2(DigitSeq, DigitSeq_2);
    }
}

static void
eval_DigitSeq(struct DigitSeq *DigitSeq) {
    if (DigitSeq->alt_number == 1) {
        eval_DigitSeq_1(DigitSeq, &DigitSeq->alternatives.DigitSeq_1);
    }
    if (DigitSeq->alt_number == 2) {
        eval_DigitSeq_2(DigitSeq, &DigitSeq->alternatives.DigitSeq_2);
    }
}

static void
propagate_Number_1(struct Number *Number, struct Number_1 *Number_1) {
    if (!is_set(Number_1->DigitSeq->base)
    &&  is_set(Number_1->BaseTag->base)
    ) {
        set(Number_1->DigitSeq->base, val(Number_1->BaseTag->base));
    }

    if (!is_set(Number->value)
    &&  is_set(Number_1->DigitSeq->value)
    ) {
        set(Number->value, val(Number_1->DigitSeq->value));
    }
}

static void
eval_Number_1(struct Number *Number, struct Number_1 *Number_1) {
    /* propagate attributes */
    if (pre_call) {
        propagate_Number_1(Number, Number_1);
    }

    /* traverse subtrees */
    eval_DigitSeq(Number_1->DigitSeq);
    eval_BaseTag(Number_1->BaseTag);

    /* propagate attributes */
    if (post_call) {
        propagate_Number_1(Number, Number_1);
    }
}

void
eval_Number(struct Number *Number) {
    if (Number->alt_number == 1) {
        eval_Number_1(Number, &Number->alternatives.Number_1);
    }
}
