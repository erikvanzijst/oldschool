#include    "tree.h"

/* Create routines for the tree, just for the demo */

struct Number *create_Number_1(
    struct DigitSeq *DigitSeq,
    struct BaseTag *BaseTag
) {
    struct Number *node = new_node(struct Number);

    node->alt_number = 1;
    node->alternatives.Number_1.DigitSeq = DigitSeq;
    node->alternatives.Number_1.BaseTag = BaseTag;
    return node;
}

struct DigitSeq *create_DigitSeq_1(
    struct DigitSeq *DigitSeq,
    struct Digit *Digit
) {
    struct DigitSeq *node = new_node(struct DigitSeq);

    node->alt_number = 1;
    node->alternatives.DigitSeq_1.DigitSeq = DigitSeq;
    node->alternatives.DigitSeq_1.Digit = Digit;
    return node;
}

struct DigitSeq *create_DigitSeq_2(
    struct Digit *Digit
) {
    struct DigitSeq *node = new_node(struct DigitSeq);

    node->alt_number = 2;
    node->alternatives.DigitSeq_2.Digit = Digit;
    return node;
}

struct Digit *create_Digit_1(
    struct Token *Token
) {
    struct Digit *node = new_node(struct Digit);

    node->alt_number = 1;
    node->alternatives.Digit_1.Token = Token;
    return node;
}

struct BaseTag *create_BaseTag_1(
    void
) {
    struct BaseTag *node = new_node(struct BaseTag);

    node->alt_number = 1;
    return node;
}

struct BaseTag *create_BaseTag_2(
    void
) {
    struct BaseTag *node = new_node(struct BaseTag);

    node->alt_number = 2;
    return node;
}

struct Token *create_Token(
    char ch
) {
    struct Token *node = new_node(struct Token);

    node->class = 257;
    node->repr = ch;
    return node;
}
