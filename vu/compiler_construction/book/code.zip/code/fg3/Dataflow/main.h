extern int pre_call;
extern int post_call;
