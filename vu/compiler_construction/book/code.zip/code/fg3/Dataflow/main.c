#include    <stdio.h>
#include    <stdlib.h>

#include    "main.h"
#include    "tree.h"
#include    "eval.h"

int pre_call;
int post_call;

int
main(int argc, char *argv[]) {
    struct Number *Number;

    while (argc > 1 && argv[1][0] == '-') {
        switch (argv[1][1]) {
        case 'b':
            pre_call = 1;
            break;
        case 'a':
            post_call = 1;
            break;
        }
        argc--, argv++;
    }

    if (!pre_call && ! post_call) {
        fprintf(stderr, "Dataflow: neither -a nor -b specified\n");
        exit(1);
    }

    /* construct a test tree */
    Number =
        create_Number_1(
            create_DigitSeq_1(
                create_DigitSeq_1(
                    create_DigitSeq_2(
                        create_Digit_1(create_Token('5'))
                    ),
                    create_Digit_1(create_Token('6'))
                ),
                create_Digit_1(create_Token('7'))
            ),
            create_BaseTag_1()
        );

    /* run the dataflow machine */
    while (!is_set(Number->value)) {
        printf("Evaluate for Number called\n");
        eval_Number(Number);
    }

    /* print one attribute */
    printf("Number.value = %d\n", val(Number->value));

    return 0;
}
