#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>


#define IF      258
#define THEN    259
#define ELSE    260
#define LET     261
#define IN      262
#define NIL     263
#define NUMBER  264
#define IDENTIFIER      265
#define OPERATOR      266

#define NNUM	0

#include "scanner.i"

#define next_token()	(token = yylex())
static void expr( int strict);


static int token;
static char *local_defs = NULL;
static char *pattern_match = NULL;
static char *expr_code = NULL;
static FILE *hdr;

static struct sym_info { char *fun; int arity;} *sym_tab = NULL;
static int nsyms = 0;


static
void memory_error( void)
{
    fprintf( stderr, "[line %3d] out of memory on input: '%s'\n",
    	     line_number, yytext);
    exit(13);
}

sym_insert( char *fun, int arity)
{
    if (nsyms == 0)
	sym_tab = (struct sym_info *)malloc(sizeof(struct sym_info));
    else
	sym_tab = (struct sym_info *)realloc(sym_tab, (nsyms+1) * sizeof(struct sym_info));
    if (sym_tab == 0) memory_error();
    sym_tab[nsyms].fun = strdup(fun);
    sym_tab[nsyms].arity = arity;
    nsyms++;
}

int sym_lookup( char *fun)
{
    int i;

    for (i=0; i<nsyms; i++)
	if (strcmp( fun, sym_tab[i].fun) == 0) {
	    return( sym_tab[i].arity);
	}

    return -1;
}

static void append( char **head, char *tail)
{
    if (*head == NULL) {
        *head = strdup(tail);
    } else {
    	*head = (char *)realloc( *head, strlen(*head) + strlen(tail) + 1);
	if (*head == 0) memory_error();
    	strcat(*head, tail);
    }
}

static void prepend( char **head, char *prefix)
{
    char *tail = *head;

    *head = NULL;
    append( head, prefix);
    if (tail != NULL) {
    	append( head, tail);
	free( tail);
    }
}

static void append_pattern( char *pattern)
{
    append( &pattern_match, pattern);
}

static void append_local( char *local)
{
    append( &local_defs, local);
}

static void append_code( char *code)
{
    append( &expr_code, code);
}

static void prepend_code( char *code)
{
    prepend( &expr_code, code);
}

static char *op2fun( char *op)
{
    switch (*op) {
      case '+':
      	return "add";
      case '-':
      	return "sub";
      case '*':
      	return "mul";
      case '/':
      	return "div";
      case '<':
      	return "less";
      case '>':
      	return "greater";
      case '=':
      	return "equal";
    }
    printf( "operator '%s' not implemented\n", op);
    exit(1);
    return 0;
}

static
void parse_error( void)
{
    fprintf( stderr, "[line %3d] parse error on input: '%s'\n",
    	     line_number, yytext);
    exit(13);
}

static
void skip( int expected)
{
    while (token == expected) {
	next_token();
    }
}

static
void match( int expected)
{
    if (token != expected) {
	parse_error();
    }
}

static int global_name( char *name)
{
    return (local_defs == NULL) || !strstr(local_defs, name);
}

static char *builtin[] = {"less", "add", "sub", "mul", "div", "equal"};

static int func_arity( char *fun)
{
    int op;

    for ( op = 0; op < sizeof(builtin)/sizeof(char *); op++)
        if (strcmp(fun, builtin[op]) == 0)
	    return 2;
    return sym_lookup( fun);
}

static int strict_arg( char *fun, int arg)
{
    int op;

    for ( op = 0; op < sizeof(builtin)/sizeof(char *); op++)
        if (strcmp(fun, builtin[op]) == 0) {
	    assert( 0 <= arg && arg < 2);
	    return 1;
	}

    return 0;
}

static void eval(int now)
{
    char *fun;
    char *orig;
    char *start, *end;
    char *prefix;
    int a, args, brackets;

    if (now) {
	/* symbolic interpretation of 'expr_code' to find out if we
	 * can do better than generating an eval call to be evaluated at
	 * runtime.
	 */
	if (strcmp(expr_code, "Nil()") == 0)
	    return;
	if (strstr(expr_code, "Num(") == expr_code)
	    return;
	if (strstr(expr_code, "_Number") == expr_code)
	    return;

	for ( fun = expr_code, args=0; strstr(fun, "Appl(") == fun; args++)
	    fun += strlen( "Appl(");

	if (fun != expr_code) {		/* Did we find a func appl? */
	    fun += 3;			/* skip "&__" */
	    start = strchr(fun, ',');
	    *start = '\0';
	    if (func_arity(fun) == args) {
	        /* Appl(Appl(op,arg1),arg2) => op(arg1,arg2)
	         */
	        orig = expr_code; expr_code = NULL;
	        append_code(fun);
	        append_code("(");
	        for (a=0; a<args; a++) {
	    	/* find end of arg by counting brackets
	    	 */
	    	brackets = 0;
	    	for ( end = ++start; *end != ')' || brackets>0; end++)
	    	    if (*end == '(')
	    		brackets++;
	    	    else if (*end == ')')
	    		brackets--;
	    	*end++ = '\0';

	    	prefix = expr_code; expr_code = NULL;
	    	append_code(start);
	    	if (strict_arg(fun,a)) eval(1);
	    	prepend_code( prefix);

	            start = strchr(end, ',');
	    	if (start != NULL) {
	    	    append_code( ",");
	    	}
	        }
	        append_code(")");
	        free( orig);
	        return;
	    }
	    *start = ',';
	}
    }
    prepend_code( "eval(");
    append_code( ")");
}

static
int value( int strict)
{
    switch (token) {			int num;
      case NIL:				append_code( "Nil()");
        next_token();
	return 1;
	break;

      case NUMBER:			num = atoi(yytext);
					if (0 <= num && num < NNUM) {
      					    append_code( "_Number[");
					    append_code( yytext);
					    append_code( "]");
					} else {
      					    append_code( "Num(");
					    append_code( yytext);
					    append_code( ")");
					}
        next_token();
	return 1;
	break;

      case IDENTIFIER:			if (global_name( yytext)) {
					    append_code( "&__");
					    append_code( yytext);
					} else {
					    if (strict) append_code( "eval(");
					    append_code( yytext);
					    if (strict) append_code( ")");
					}
        next_token();
	return 1;
	break;

      case '(':				append_code( yytext);
        next_token();			
	if (token == OPERATOR) {	append_code( "&__");
					append_code( op2fun(yytext));
	    next_token();
	} else
	    expr(strict);
	match( ')');			append_code( yytext);
        next_token();
	return 1;
	break;

      default:
	return 0;
	break;
    }
}

static
void term( int strict)
{
					int func_appl = 0;
					char *fun;
					char *prefix = expr_code;
					expr_code = NULL;
    if (!value(strict)) parse_error();	fun = expr_code; expr_code = NULL;
    while (value(0)) {			/* fun arg => Appl(fun,arg)
					 */
					func_appl = 1;
					prepend_code( ",");
    					prepend_code( fun);
					prepend_code( "Appl(");
					append_code( ")");
    					fun = expr_code; expr_code = NULL;
    }
					expr_code = fun;
					if (strict && func_appl)
					    eval(strict);
    					if (prefix != NULL)
					    prepend_code(prefix);
}

static
void factor( int strict)
{					char *left;
					char *prefix = expr_code;
					expr_code = NULL;
    term(strict);		
    while (token == OPERATOR) {		/* term1 op term2 =>
					 * Appl(Appl(op,term1),term2) |
					 * op(term1,term2)
					 */
					if (strict)
					    prepend_code( "(");
					else
					    prepend_code( ",");
					prepend_code( op2fun(yytext));
					if (!strict) {
					    prepend_code( "Appl(Appl(&__");
					    append_code( ")");
					}
					append_code( ",");
					left = expr_code; expr_code = NULL;
    	next_token();
    	term(strict);			append_code(")");
					prepend_code( left);
    }
    					if (prefix != NULL)
					    prepend_code(prefix);
}

static
void definition( void)
{
					char id[100], *prefix;
    match(IDENTIFIER);			sprintf(id, "%s", yytext);
    next_token();
    match('=');
    next_token();			prefix = expr_code; expr_code = NULL;
    expr(0);				append_local( "\tPnode ");
					append_local( id);
					append_local( " = ");
					append_local( expr_code);
     					append_local( ";\n");
					expr_code = prefix;
}

static
void expr( int strict)
{
    if (token == IF) {			
	next_token();
	factor(strict);			if (!strict) eval(strict);
					append_code( "->nd.num ? ");
	skip( '\n');
	match( THEN);			
	next_token();
	expr(strict);
	skip( '\n');
	match( ELSE);			append_code( " : ");
	next_token();
	expr(strict);			
    } else if (token == LET) {
	next_token();			
	skip( '\n');
	do {
	    definition();
	    skip('\n');
	} while (token != IN);
	next_token();
	skip( '\n');
	expr(strict);
    } else {				char *prefix = expr_code;
					expr_code = NULL;
        factor(0);
        if (token == ':') {		prepend_code( "Cons(");
					append_code( ",");
	    next_token();
	    expr(0);			append_code( ")");
	} else {
					if (strict) eval(strict);
	}
    					if (prefix != NULL)
					    prepend_code(prefix);
    }
}

static
int param( int argn)
{
    					char buf[100];
    switch (token) {
      case IDENTIFIER:			sprintf( buf, "\tPnode %s = _arg%d;\n",
					         yytext, argn);
					append_local(buf);
        next_token();
	break;

      case NIL:				sprintf( buf, "(_arg%d = eval(_arg%d))->tag == NIL",
					         argn, argn);
					append_pattern(buf);
        next_token();
	break;

      case NUMBER:			sprintf( buf, "(_arg%d = eval(_arg%d))->nd.num == %s",
						  argn, argn, yytext);
					append_pattern(buf);
        next_token();
	break;

      case '(':				sprintf( buf, "(_arg%d = eval(_arg%d))->tag == CONS",
					         argn, argn);
					append_pattern(buf);
        next_token();
	match( IDENTIFIER);		sprintf( buf, "Pnode %s = _arg%d->nd.cons.hd; ",
					         yytext, argn);
					append_local(buf);
        next_token();
	match( ':');
        next_token();
	match( IDENTIFIER);		sprintf( buf, "Pnode %s = _arg%d->nd.cons.tl;",
					         yytext, argn);
					append_local(buf);
        next_token();
	match( ')');
        next_token();
	break;

      default:
        return 0;
	break;
    }
    return 1;
}

static
int params(void)
{
    int par = 0;

    while (param(par))
    	par++;
    return par;
}

static void prelude( char *fun, int arity)
{
    int i;

    /* Code for prelude function
     */
    printf( "static Pnode _%s(Pnode *arg)\n{\n\treturn %s(", fun, fun);
    for ( i=0; i<arity; i++) {
	if (i>0) printf( ", ");
        printf( "arg[%d]", i);
    }
    printf( ");\n}\n\n");

    /* Function node
     */
    printf( "struct node __%s = {FUNC, {%d, \"%s\", _%s}};\n\n",
    	    fun, arity, fun, fun);

    /* Declare function node for forward refs
     */
    fprintf( hdr, "extern struct node __%s;\n", fun);
}

static
void function( int strict)
{
    				static int arity;
    				static char *current = NULL;
				static int was_pattern_match = 0;
				int heading = 0;
				int i;
    match(IDENTIFIER);		
				if (current == NULL) {
				    current = strdup(yytext);
				    heading = 1;
				} else if (strcmp(yytext, current) != 0) {
				    if (was_pattern_match) {
				        printf( "abort(/*%s*/); ", current);
				        printf( "return 0;");
				        was_pattern_match = 0;
				    }
				    printf( "}\n\n");
				    prelude( current, arity);
				    free( current);
				    if (strcmp(yytext, "main") == 0)
				        current = strdup("_main");
				    else
				        current = strdup(yytext);
				    heading = 1;
				}
    next_token();
    arity = params();
				if (heading) {
				    printf( "Pnode %s(", current);
				    for ( i=0; i<arity; i++) {
					if (i>0) printf( ", ");
				        printf( "Pnode _arg%d", i);
				    }
				    if (arity == 0) printf( "void");
    				    printf( ")\n{\n");
				    sym_insert( current, arity);
    				}

    				if (pattern_match != NULL) {
				    printf( "if (%s) {", pattern_match);
    				}
    match( '=');		
    next_token();
    expr(strict);		if (local_defs != NULL) {
				    printf( "%s\n", local_defs);
				}
    				assert(expr_code != NULL);
				printf( "\treturn %s;", expr_code);
				expr_code = NULL;
				if (pattern_match) {
				    printf( "}");
				    free(pattern_match);
				    pattern_match = NULL;
				    was_pattern_match = 1;
				}
				if (local_defs != NULL) {
				    free( local_defs);
				    local_defs = NULL;
				}
    next_token();
    skip('\n');			printf( "\n");
				if (token == 0) {
				    printf( "}\n");
				    prelude( current, arity);
				}
}

static
void program(int strict)
{
    next_token();
    skip( '\n');
    while (token != 0) {
	function( strict);
    }
}

main(int argc, char *argv[])
{
    int i;
    char *dot;
    int strictness = 0;

    for (i=1; i< argc; i++) {
	if (strcmp(argv[i],"-strict") == 0) {
	    strictness = 1;
	    continue;
	}
	if (strcmp(argv[i]+strlen(argv[i])-3, ".hs") != 0) {
	    printf( "%s: can't process '%s' because of missing '.hs' suffix\n",
	    	    argv[0], argv[i]);
	    continue;
	}
	if (freopen( argv[i], "r", stdin) == NULL) {
	    perror( argv[i]);
	}
	dot = strrchr( argv[i], '.');
	sprintf( dot, ".c");
	if (freopen( argv[i], "w", stdout) == NULL) {
	    perror( argv[i]);
	}
	dot = strrchr( argv[i], '.');
	sprintf( dot, ".h");
	if ((hdr = fopen( argv[i], "w")) == NULL) {
	    perror( argv[i]);
	}
	printf( "#include <stdio.h>\n");
	printf( "#include \"node.h\"\n");
	printf( "#include \"built-in.h\"\n");
	printf( "#include \"eval.h\"\n");
	printf( "#include \"print.h\"\n");
	printf( "#include \"%s\"\n", argv[i]);
	printf( "\nPnode _Number[%d];\n\n", NNUM);

    	program(strictness);

	printf( "\nmain(void)\n{\n");
	printf( "\tint i;\n\n");
	printf( "\tfor (i=0; i < %d; i++) _Number[i] = Num(i);\n", NNUM);
	printf( "\tprint(&___main);\n");
	printf( "\texit(0);\n");
	printf( "}\n");
    }
    exit(0);
}
