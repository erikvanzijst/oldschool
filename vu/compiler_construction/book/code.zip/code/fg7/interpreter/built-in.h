/* Built-in primitives
 */

extern Pnode add_evaluated(Pnode a, Pnode b);
extern Pnode add(Pnode _arg0, Pnode _arg1);
extern Pnode _add(Pnode *arg);
extern struct node __add;

extern Pnode sub_evaluated(Pnode a, Pnode b);
extern Pnode sub(Pnode _arg0, Pnode _arg1);
extern Pnode _sub(Pnode *arg);
extern struct node __sub;

extern Pnode mul_evaluated(Pnode a, Pnode b);
extern Pnode mul(Pnode _arg0, Pnode _arg1);
extern Pnode _mul(Pnode *arg);
extern struct node __mul;

extern Pnode div_evaluated(Pnode a, Pnode b);
extern Pnode div(Pnode _arg0, Pnode _arg1);
extern Pnode _div(Pnode *arg);
extern struct node __div;

extern Pnode less_evaluated(Pnode a, Pnode b);
extern Pnode less(Pnode _arg0, Pnode _arg1);
extern Pnode _less(Pnode *arg);
extern struct node __less;

extern Pnode equal_evaluated(Pnode a, Pnode b);
extern Pnode equal(Pnode _arg0, Pnode _arg1);
extern Pnode _equal(Pnode *arg);
extern struct node __equal;
