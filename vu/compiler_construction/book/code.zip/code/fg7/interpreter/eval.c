#include "node.h"
#include "eval.h"

#define STACK_DEPTH     10000

static Pnode arg[STACK_DEPTH];
static int top = STACK_DEPTH;                    /* grows down */

Pnode eval(Pnode root) {
    Pnode node = root;
    int frame, arity;

    frame = top;
    for (;;) {
        switch (node->tag) {
        case APPL:                                   /* unwind */
            arg[--top] = node->nd.appl.arg;  /* stack argument */
            node = node->nd.appl.fun;      /* application node */
            break;

        case FUNC:
            arity = node->nd.func.arity;
            if (frame-top < arity) {       /* curried function */
                top = frame;
                return root;
            }
            node = node->nd.func.code(&arg[top]);    /* reduce */
            top += arity;                 /* unstack arguments */
            *root = *node;              /* update root pointer */
            break;

        default:
            return node;
        }
    }
}
