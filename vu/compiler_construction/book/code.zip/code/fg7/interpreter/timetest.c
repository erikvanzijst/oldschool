#include "node.h"
#include "built-in.h"
#include "eval.h"
#include "print.h"

extern struct node __take;
extern struct node __map;
extern struct node __fac;
extern struct node __repeat;
extern struct node __max;
extern struct node __max1;
extern struct node ___main;

Pnode _Number[10];

Pnode take(Pnode _arg0, Pnode _arg1)
{
if ((_arg0 = eval(_arg0))->nd.num == 0) {	Pnode lst = _arg1;

	return Nil();}
if ((_arg1 = eval(_arg1))->tag == NIL) {	Pnode n = _arg0;

	return Nil();}
if ((_arg1 = eval(_arg1))->tag == CONS) {	Pnode n = _arg0;
Pnode x = _arg1->nd.cons.hd; Pnode xs = _arg1->nd.cons.tl;
	return Cons(x,Appl(Appl(&__take,(Appl(Appl(&__sub,n),Num(1)))),xs));}
abort(/*take*/); return 0;}

static Pnode _take(Pnode *arg)
{
	return take(arg[0], arg[1]);
}

struct node __take = {FUNC, {2, "take", _take}};

Pnode map(Pnode _arg0, Pnode _arg1)
{
if ((_arg1 = eval(_arg1))->tag == NIL) {	Pnode f = _arg0;

	return Nil();}
if ((_arg1 = eval(_arg1))->tag == CONS) {	Pnode f = _arg0;
Pnode x = _arg1->nd.cons.hd; Pnode xs = _arg1->nd.cons.tl;
	return Cons(Appl(f,x),Appl(Appl(&__map,f),xs));}
abort(/*map*/); return 0;}

static Pnode _map(Pnode *arg)
{
	return map(arg[0], arg[1]);
}

struct node __map = {FUNC, {2, "map", _map}};

extern Pnode fac(Pnode _arg0);
#if defined(INTERPRETER)
#include "fac-interpreter.i"
#elif defined(TOP_LEVEL)
#include "fac-top-level.i"
#elif defined(BUILT_IN)
#include "fac-lazy.i"
#elif defined(STRICT)
#include "fac-allstrict.i"
#elif defined(UNBOXED)
#include "fac-unboxed.i"
#elif defined(ACCUM)
#include "fac-acc.i"

Pnode fac_evaluated(Pnode _arg0) {
    Pnode n = _arg0;

    return Num(fac_unboxed(n->nd.num));
}

Pnode fac(Pnode _arg0) {
    return fac_evaluated(eval(_arg0));
}
#endif

static Pnode _fac(Pnode *arg)
{
	return fac(arg[0]);
}

struct node __fac = {FUNC, {1, "fac", _fac}};

Pnode repeat(Pnode _arg0)
{
	Pnode n = _arg0;

	return Cons(n,Appl(&__repeat,n));
}

static Pnode _repeat(Pnode *arg)
{
	return repeat(arg[0]);
}

struct node __repeat = {FUNC, {1, "repeat", _repeat}};

Pnode max(Pnode _arg0)
{
if ((_arg0 = eval(_arg0))->tag == CONS) {Pnode x = _arg0->nd.cons.hd; Pnode xs = _arg0->nd.cons.tl;
	return Appl(Appl(&__max1,x),xs);}
abort(/*max*/); return 0;}

static Pnode _max(Pnode *arg)
{
	return max(arg[0]);
}

struct node __max = {FUNC, {1, "max", _max}};

Pnode max1(Pnode _arg0, Pnode _arg1)
{
if ((_arg1 = eval(_arg1))->tag == NIL) {	Pnode m = _arg0;

	return m;}
if ((_arg1 = eval(_arg1))->tag == CONS) {	Pnode m = _arg0;
Pnode x = _arg1->nd.cons.hd; Pnode xs = _arg1->nd.cons.tl;
	return eval((Appl(Appl(&__less,m),x)))->nd.num ? Appl(Appl(&__max1,x),xs) : Appl(Appl(&__max1,m),xs);}
abort(/*max1*/); return 0;}

static Pnode _max1(Pnode *arg)
{
	return max1(arg[0], arg[1]);
}

struct node __max1 = {FUNC, {2, "max1", _max1}};

Pnode _main(void)
{
	return Appl(&__max,(Appl(Appl(&__map,&__fac),(Appl(Appl(&__take,Num(40)),(Appl(&__repeat,Num(4000))))))));
}
static Pnode __main(Pnode *arg)
{
	return _main();
}

struct node ___main = {FUNC, {0, "_main", __main}};


main(void)
{
	int i;

	for (i=0; i < 10; i++) _Number[i] = Num(i);
	print(&___main);
	exit(0);
}
