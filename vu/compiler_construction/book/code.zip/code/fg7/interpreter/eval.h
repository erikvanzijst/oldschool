/* Node evaluation
 */
extern Pnode eval(Pnode node);
