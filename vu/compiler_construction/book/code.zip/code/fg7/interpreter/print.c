#include <stdio.h>

#include "node.h"
#include "eval.h"
#include "print.h"

static void dump(Pnode node, int braces)
{
    switch (node->tag) {
      case NUM:
	printf("%d", node->nd.num);
	break;

      case FUNC:
	printf("%s", node->nd.func.name);
	break;

      case CONS:
	if (braces)
	    printf("(");
	dump((node->nd.cons.hd), 1);
	printf(":");
	dump((node->nd.cons.tl), 0);
	if (braces)
	    printf(")");
	break;

      case NIL:
	printf("[]");
	break;

      case APPL:
	if (braces)
	    printf("(");
	dump((node->nd.appl.fun), 0);
	printf(" ");
	dump((node->nd.appl.arg), 1);
	if (braces)
	    printf(")");
	break;
    }
}


static void pr(Pnode node, int braces)
{
    switch (node->tag) {
      case NUM:
	printf("%d", node->nd.num);
	break;

      case FUNC:
	printf("%s", node->nd.func.name);
	break;

      case CONS:
	if (braces)
	    printf("(");
	pr(eval(node->nd.cons.hd), 1);
	printf(":");
	pr(eval(node->nd.cons.tl), 0);
	if (braces)
	    printf(")");
	break;

      case NIL:
	printf("[]");
	break;

      case APPL:
	if (braces)
	    printf("(");
	pr(eval(node->nd.appl.fun), 0);
	printf(" ");
	pr(eval(node->nd.appl.arg), 1);
	if (braces)
	    printf(")");
	break;
    }
}

void print(Pnode node)
{
    dump(node, 0);
    printf( "\n\t");
    pr(eval(node), 0);
    printf( "\n");
}
