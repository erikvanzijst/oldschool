#include "node.h"
#include "built-in.h"
#include "eval.h"


Pnode add_evaluated(Pnode a, Pnode b) {
    return Num(a->nd.num + b->nd.num);
}

Pnode add(Pnode _arg0, Pnode _arg1) {
    Pnode a = eval(_arg0);
    Pnode b = eval(_arg1);

    return add_evaluated(a, b);
}

Pnode _add(Pnode *arg) {
    return add(arg[0], arg[1]);
}

struct node __add = {FUNC, {2, "add", _add}};


Pnode sub_evaluated(Pnode a, Pnode b) {
    return Num(a->nd.num - b->nd.num);
}

Pnode sub(Pnode _arg0, Pnode _arg1) {
    Pnode a = eval(_arg0);
    Pnode b = eval(_arg1);

    return sub_evaluated(a, b);
}

Pnode _sub(Pnode *arg) {
    return sub(arg[0], arg[1]);
}

struct node __sub = {FUNC, {2, "sub", _sub}};


Pnode mul_evaluated(Pnode a, Pnode b) {
    return Num(a->nd.num * b->nd.num);
}

#include "mul.i"


Pnode div_evaluated(Pnode a, Pnode b) {
    return Num(a->nd.num / b->nd.num);
}

Pnode div(Pnode _arg0, Pnode _arg1) {
    Pnode a = eval(_arg0);
    Pnode b = eval(_arg1);

    return div_evaluated(a, b);
}

Pnode _div(Pnode *arg) {
    return div(arg[0], arg[1]);
}

struct node __div = {FUNC, {2, "div", _div}};


Pnode less_evaluated(Pnode a, Pnode b) {
    return Num(a->nd.num < b->nd.num);
}

Pnode less(Pnode _arg0, Pnode _arg1) {
    Pnode a = eval(_arg0);
    Pnode b = eval(_arg1);

    return less_evaluated(a, b);
}

Pnode _less(Pnode *arg) {
    return less(arg[0], arg[1]);
}

struct node __less = {FUNC, {2, "less", _less}};


Pnode equal_evaluated(Pnode a, Pnode b) {
    return Num(a->nd.num == b->nd.num);
}

Pnode equal(Pnode _arg0, Pnode _arg1) {
    Pnode a = eval(_arg0);
    Pnode b = eval(_arg1);

    return equal_evaluated(a, b);
}

Pnode _equal(Pnode *arg) {
    return equal(arg[0], arg[1]);
}

struct node __equal = {FUNC, {2, "equal", _equal}};
