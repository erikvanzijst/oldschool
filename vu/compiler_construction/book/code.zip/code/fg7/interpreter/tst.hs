take 0 lst    = []
take n []     = []
take n (x:xs) = x : take (n-1) xs

from n = n : from (n+1)

map f []     = []
map f (x:xs) = f x : map f xs

nfib n = if (n < 2) then 1
         else 1 + nfib (n-1) + nfib (n-2)

sum []     = 0
sum (x:xs) = x + sum xs

main = map nfib (take 22 nats)

nats = from 1

taketwenty = take 20

twice f x = f (f x)

fac n = if (n == 0) then 1
	else n * fac (n-1)

foo a = let
	  b = fac a
	  c = b * b
	in
	  c + c

bar a = let
	  c = let b = fac a in b * b
	in
	  c + c

average a b = (a+b) / 2
