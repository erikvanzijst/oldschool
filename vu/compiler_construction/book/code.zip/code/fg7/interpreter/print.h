/* Output
 */
extern void print(Pnode node);

