#include "node.h"
#include <stdio.h>
#include <stdlib.h>

void *Malloc(size_t s)
{
    void *new = malloc(s);
    
    if (new == 0) {
        fprintf( stderr, "Out of memory\n");
        exit(1);
    }
    return new;
}

Pnode Func(int arity, const char *name, unary code)
{
    Pnode node = (Pnode) Malloc( sizeof(*node));

    node->tag = FUNC;
    node->nd.func.arity  = arity;
    node->nd.func.name  = name;
    node->nd.func.code  = code;
    return node;
}

Pnode Num(int num)
{
    Pnode node = (Pnode) Malloc( sizeof(*node));

    node->tag = NUM;
    node->nd.num = num;
    return node;
}

Pnode Nil(void)
{
    static struct node nil = {NIL,};

    return &nil;
}

Pnode Cons(Pnode hd, Pnode tl)
{
    Pnode node = (Pnode) Malloc( sizeof(*node));

    node->tag = CONS;
    node->nd.cons.hd = hd;
    node->nd.cons.tl = tl;
    return node;
}

#define heap_alloc    Malloc
#include "appl.i"
