Pnode conditional(Pnode _arg0, Pnode _arg1, Pnode _arg2) {
    Pnode cond = _arg0;
    Pnode _then = _arg1;
    Pnode _else = _arg2;

    return eval(cond)->nd.num ? _then : _else;
}

Pnode _conditional(Pnode *arg) {
    return conditional(arg[0], arg[1], arg[2]);
}

struct node __conditional =
    {FUNC, {3, "conditional", _conditional}};
