main = take 100 [1..]
