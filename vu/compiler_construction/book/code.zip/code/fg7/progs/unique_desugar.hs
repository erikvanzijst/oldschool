unique a1 = if (_type_constr a1 == Cons &&
                _type_constr (_type_field 2 a1) == Cons) then
              let
                 a  = _type_field 1 a1
                 b  = _type_field 1 (_type_field 2 a1)
                 cs = _type_field 2 (_type_field 2 a1)
              in
                if (a == b) then a : unique cs
                else a : unique (b:cs)
            else
              a1
