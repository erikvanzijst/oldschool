sv_mul scal vec = let
                    s_mul x = scal * x
                  in
                    map s_mul vec
