sv_mul_dot_s_mul scal x = scal * x

sv_mul scal vec = map (sv_mul_dot_s_mul scal) vec
