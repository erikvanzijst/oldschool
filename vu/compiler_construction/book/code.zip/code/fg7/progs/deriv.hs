deriv f x = (f (x+h) - f x) / h
            where
              h = 0.0001
