qsort []     = []
qsort (x:xs) = qsort (mappend (qleft x) xs) ++ [x]
               ++ qsort (mappend (qright x) xs)

qleft x y  = if (y < x)  then [y] else []

qright x y = if (y >= x) then [y] else []
