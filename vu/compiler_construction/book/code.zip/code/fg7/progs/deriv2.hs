deriv f x = lim [(f (x+h) - f x)/h | h <- [1/2^n | n<-[1..]]]
            where
                lim (a:b:lst) = if abs(a/b - 1) < eps then b
                                else lim (b:lst)
                eps = 1.0e-6
