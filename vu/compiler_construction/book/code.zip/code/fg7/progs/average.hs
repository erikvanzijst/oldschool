average a b = (a+b) / 2
