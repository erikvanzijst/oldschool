safe_div a b = if (b == 0) then 0
               else a/b
