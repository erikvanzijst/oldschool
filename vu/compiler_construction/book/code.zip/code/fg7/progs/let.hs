f a = let
        b = fac a
        c = b * b
      in
        c + c
