qsort []     = []
qsort (x:xs) = qsort (mappend qleft xs) ++ [x]
               ++ qsort (mappend qright xs)
               where
                 qleft y  = if (y < x)  then [y] else []
                 qright y = if (y >= x) then [y] else []
