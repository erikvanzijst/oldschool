tree 0 val = val
tree n val = let t = tree (n-1) val in t*t

main = print (tree 10 (fac 20))
