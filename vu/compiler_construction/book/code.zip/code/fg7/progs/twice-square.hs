let
  twice f x = f (f x)
  square n = n*n
in
  twice square 3
