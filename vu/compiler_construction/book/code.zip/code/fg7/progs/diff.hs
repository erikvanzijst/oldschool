diff f = f_
         where
           f_ x = (f (x+h) - f x) / h
           h    = 0.0001
