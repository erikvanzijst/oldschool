fac n = if (n == 0) then 1 else prod n (n-1)
        where
          prod acc n = if (n == 0) then acc
                       else prod (acc*n) (n-1)
