f x y z 0 = x + z
f x y z p = f y 0 0 (p-1) + f z z 0 (p-1)
