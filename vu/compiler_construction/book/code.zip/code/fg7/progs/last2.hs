last a1 = if (_type_constr a1 == Cons) then
            let
              x  = _type_field 1 a1
              xs = _type_field 2 a1
            in
              if (xs == []) then
                x
              else
                last xs
          else
            error "last: no matching pattern"
