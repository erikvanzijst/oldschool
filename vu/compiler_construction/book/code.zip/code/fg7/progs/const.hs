let
  const c x = c
in
  const 1 (2+3)
