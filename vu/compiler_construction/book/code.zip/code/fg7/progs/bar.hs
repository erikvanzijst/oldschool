g x y z = if (z == 0) then x
          else g y x (z-1)
