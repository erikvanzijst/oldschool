pyth n = mappend f_bc2 [1..n]
         where
           f_bc2 a = mappend f_c2 [a .. n]
                     where
                       f_c2 b = mappend f_2 [b .. n]
                                where
                                  f_2 c = if (a^2 + b^2 == c^2)
                                          then [(a,b,c)]
                                          else []
