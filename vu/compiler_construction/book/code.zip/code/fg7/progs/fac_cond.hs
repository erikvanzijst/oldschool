cond b t e = if b then t else e

fac n = cond (n==0) 1 (n * fac (n-1))
