add_one []     = []
add_one (x:xs) = x+1 : add_one xs
