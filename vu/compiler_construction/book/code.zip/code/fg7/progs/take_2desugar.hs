take a1 a2 = if (a1 == 0) then
               let xs = a2 in []
             else if (a2 == []) then
               let n = a1 in []
             else
               let
                 n  = a1
                 x  = _type_field 1 a2
                 xs = _type_field 2 a2
               in
                 x : take (n-1) xs
