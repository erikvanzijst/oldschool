unique (a:b:cs) = if (a == b) then a : unique cs
                  else a : unique (b:cs)
unique cs       = cs
