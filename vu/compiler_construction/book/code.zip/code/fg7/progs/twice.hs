twice f x = f (f x)
