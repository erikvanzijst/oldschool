foldr op val []     = val
foldr op val (x:xs) = op x (foldr op val xs)
