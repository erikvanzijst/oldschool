length list = if (list == []) then 0
              else let
                     x  = head list
                     xs = tail list
                   in
                     1 + length xs
