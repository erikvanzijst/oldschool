f a b = if (a == 0) then b
        else f (a-1) (b+1)
