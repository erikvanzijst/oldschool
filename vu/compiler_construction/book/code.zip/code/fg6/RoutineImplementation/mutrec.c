#include    <stdio.h>

void do_showSP(const char *msg, const int *SP) {
    printf("%s = %o\n", msg, (int)SP);
}

#define    showSP(msg)    do_showSP(msg, &i)

void A(int i);
void B(int i);

void A(int i) {
    showSP("A.SP.entry");
    if (i > 0) {B(i-1);}
    showSP("A.SP.exit");
}

void B(int i) {
    showSP("B.SP.entry");
    if (i > 0) {A(i-1);}
    showSP("B.SP.exit");
}

int
main(void) {
    A(10);
    return 0;
}
