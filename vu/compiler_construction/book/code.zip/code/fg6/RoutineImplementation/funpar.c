#include    <stdio.h>

void do_showSP(const char *msg, const int *SP) {
    printf("%s = %o\n", msg, (int)SP);
}

#define    showSP(msg)    do_showSP(msg, &i)

void A(int i, void C(int, ...));
void B(int i, void C(int, ...));

void A(int i, void C(int, ...)) {
    showSP("A.SP.entry");
    if (i > 0) {C(i-1, A);}
    showSP("A.SP.exit");
}

void B(int i, void C(int, ...)) {
    showSP("B.SP.entry");
    if (i > 0) {C(i-1, B);}
    showSP("B.SP.exit");
}

int
main(void) {
    A(10, B);
    return 0;
}
