#include    <stdio.h>

void do_showSP(const char *msg, const int *SP) {
    printf("%s = %o\n", msg, (int)SP);
}

#define    showSP(msg)    do_showSP(msg, &i)

void A(int i, void L(void));
void B(int i, void L(void));

/*
    Labels as parameters have been implemented as routines that jump
    to local labels, in accordance with GNU C (ANSI C forbids such
    antics entirely).
*/

void A(int i, void L(void)) {
    __label__ exit;
    void L1(void) {goto exit;}

    showSP("A.SP.entry");
    if (i > 0) {B(i-1, L1); return;}
    exit: showSP("A.SP.exit"); L();
}

void B(int i, void L(void)) {
    __label__ exit;
    void L1(void) {goto exit;}

    showSP("B.SP.entry");
    if (i > 0) {A(i-1, L1); return;}
    exit: showSP("B.SP.exit"); L();
}

int
main(void) {
    void L(void) {}

    A(10, L);
    return 0;
}
