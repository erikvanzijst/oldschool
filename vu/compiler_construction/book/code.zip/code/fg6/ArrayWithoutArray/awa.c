#include    <stdio.h>
#include    <stdlib.h>

int read_integer(void) {
    int res;

    scanf("%d", &res);
    return res;
}

int no_element(int i) {
    fprintf(stderr, "There is no element number %d\n", i);
    exit(1);
}

void print_middle_element(int n, int element(int)) {
    int elem = read_integer();

    int new_element(int i) {
        return (i == n ? elem : element(i));
    }

    if (elem == 0) {
        printf("middle element = %d\n", element((n-1)/2));
    }
    else {
        print_middle_element(n + 1, new_element);
    }
}

int main(void) {
    print_middle_element(0, no_element);
    return 0;
}
