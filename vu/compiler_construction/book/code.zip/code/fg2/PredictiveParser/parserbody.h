extern void input(void);
extern void token(int tk);
extern void expression(void);
extern void term(void);
extern void parenthesized_expression(void);
extern void rest_expression(void);
