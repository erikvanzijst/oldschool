#define EoF         256
#define IDENTIFIER  257
