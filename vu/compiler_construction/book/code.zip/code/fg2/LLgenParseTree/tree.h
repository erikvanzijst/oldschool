struct expr {
    int type;           /* '-' or 'T' */
    struct expr *expr;  /* for '-' */
    struct term *term;  /* for '-' and 'T' */
};
#define new_expr()  ((struct expr *)malloc(sizeof(struct expr)))

struct term {
    int type;           /* 'I' only */
};
#define new_term()  ((struct term *)malloc(sizeof(struct term)))

extern void print_expr(struct expr *e);
extern void print_term(struct term *t);
