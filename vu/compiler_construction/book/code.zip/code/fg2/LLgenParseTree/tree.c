#include    <stdio.h>

#include    "tree.h"

void
print_expr(struct expr *e) {
    printf("(");
    switch (e->type) {
    case '-':
        print_expr(e->expr);
        printf("-");
        print_term(e->term);
        break;
    case 'T':
        print_term(e->term);
        break;
    default:
        printf("<<<<Erroneous expression>>>>");
        break;
    }
    printf(")");
}

void
print_term(struct term *t) {
    switch (t->type) {
    case 'I':
        printf("I");
        break;
    default:
        printf("<<<<Erroneous term>>>>");
        break;
    }
}
