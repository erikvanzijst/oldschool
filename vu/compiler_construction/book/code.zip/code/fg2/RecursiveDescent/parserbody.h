extern int input(void);
extern int expression(void);
extern int term(void);
extern int parenthesized_expression(void);
extern int rest_expression(void);
extern int token(int tk);
extern int require(int found);
