/*  This has to be a separate file since some systems that use a lexical
    analyser prescribe their own numerical values to be returned for
    the tokens.
*/

#define EoF         256
#define IDENTIFIER  257
#define DIGIT       258
