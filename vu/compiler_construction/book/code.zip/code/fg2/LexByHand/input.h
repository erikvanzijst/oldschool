extern char *get_input(void);
extern char *input_to_zstring(int start, int length);
