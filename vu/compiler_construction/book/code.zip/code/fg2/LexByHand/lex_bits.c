#include    <stdio.h>
#include    <stdlib.h>
#include    <strings.h>

#include    "lex_driver.i"
#include    "bit_macros.i"
#include    "char_bits.i"
#include    "note_position.i"
#include    "skip_routine.i"
#include    "rec_identifier.i"
#include    "rec_integer.i"
#include    "next_token.i"
