/* This file is not shown in the book, and is too naive */

#include    <stdlib.h>
#include    <unistd.h>
#include    <strings.h>

#include    "input.h"

static char input[500000];

char *get_input(void) {
    int n = read(0, input, sizeof(input));

    if (n == sizeof(input)) abort();
    input[n] = '\0';

    return input;
}

char *input_to_zstring(int start, int length) {
    char *result;

    strncpy(result = (char*)malloc(length+1), &input[start], length);
    result[length] = '\0';

    return result;
}
