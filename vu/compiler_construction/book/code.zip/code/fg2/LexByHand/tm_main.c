#include    "lex.h"      /* for start_lex(), get_next_token() */

int main(void) {
    start_lex();

    do {
        get_next_token();
    } while (Token.class != EoF);
    return 0;
}
