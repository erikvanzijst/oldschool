#include    "hash.h"

#include    <stdio.h>

int
main(void) {
    printf("hash(\"length\") = %d\n", hash("length"));
    printf("hash(\"width\") = %d\n", hash("width"));
    printf("hash(\"height\") = %d\n", hash("height"));

    return 0;
}
