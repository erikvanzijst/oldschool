#include    "hash.h"

#include    <stdio.h>
#include    <strings.h>

int
main(void) {
    int i, j;
    char letters[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

    for (i = 0; i < strlen(letters); i++) {
        char idf[3];

        idf[0] = letters[i];
        for (j = 0; j < strlen(letters) + 1; j++) {
            idf[1] = letters[j];
            idf[2] = '\0';
            printf("%d - %s\n", hash(idf), idf);
        }
    }

    return 0;
}
