extern int hash(const char *c);
