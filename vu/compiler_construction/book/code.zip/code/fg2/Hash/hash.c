#include    "hash.h"

#define GOOD_VALUES

#ifdef  GOOD_VALUES
#define k   613
#define N   1008
#endif

#ifdef  FAST_VALUES
#define k   4
#define N   1403
#endif

int
hash(const char *c) {
    int h = 0;

    while (*c) {
        h = k * h + *c++;
    }

    return (h & ((1<<30)-1)) % N;
}
