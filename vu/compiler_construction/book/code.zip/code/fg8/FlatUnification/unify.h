/* ======== unify.h for Flat Unification ======== */
extern int unify_terms(Term *goal_arg, Term *head_arg);
