/* ======== goalargs.c for Flat Unification ======== */
#include    "../SimpleCompiled/goalargs.c"
