/* ======== trail.h for Flat Unification ======== */

typedef int Trail_Mark;
extern void set_trail_mark(Trail_Mark *trail_mark_p);
extern void trail_binding(Term *t);
extern void restore_bindings_until_trail_mark(Trail_Mark *trail_mark_p);
