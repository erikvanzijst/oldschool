/* ======== query.c for Compiled Unification ======== */
#include    "../SimpleCompiled/query.c"
