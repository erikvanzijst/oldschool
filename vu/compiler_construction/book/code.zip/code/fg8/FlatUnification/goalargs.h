/* ======== goalargs.h for Flat Unification ======== */
#include    "../SimpleCompiled/goalargs.h"
