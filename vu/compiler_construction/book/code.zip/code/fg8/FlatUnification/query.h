/* ======== query.h for Flat Unification ======== */
#include    "../SimpleCompiled/query.h"
