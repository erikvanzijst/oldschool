/* ======== unify.c for Flat Unification ======== */
#include    "data.h"
#include    "trail.h"
#include    "unify.h"

#include    "unify_unbound_variable.i"
#include    "unify_constants.i"
#include    "unify_structures.i"
#include    "unify_non_variables.i"
#include    "unify_terms.i"
