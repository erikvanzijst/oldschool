/* ======== trail.c for Flat Unification ======== */
#include    "data.h"
#include    "trail.h"

static Term *Trail[1000];
static Trail_Mark Trail_ptr = 0;

void set_trail_mark(Trail_Mark *trail_mark_p) {
    *trail_mark_p = Trail_ptr;
}

void trail_binding(Term *t) {
    Trail[Trail_ptr++] = t;
}

void restore_bindings_until_trail_mark(Trail_Mark *trail_mark_p) {
    while (Trail_ptr != *trail_mark_p) {
        Trail[--Trail_ptr]->term.variable.term = 0;
    }
}
