/* ======== data.c for Flat Unification ======== */
#include    "../SimpleCompiled/data.c"
