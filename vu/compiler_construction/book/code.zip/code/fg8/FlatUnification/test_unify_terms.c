/* ======== test_unify_terms.c for Flat Unification ======== */
#include    <stdio.h>

#include    "data.h"
#include    "test_unify_terms.h"
#include    "unify.h"
#include    "print.h"

void test_unify_terms(Term *t1, Term *t2) {

    printf("?- unify_terms(");
    print_term(t1);
    printf(", ");
    print_term(t2);
    printf(").\n");
    if (unify_terms(t1, t2)) {
        if (t1) {
            printf("t1 = ");
            print_term(t1);
        }

        if (t2) {
            printf(", ");
            printf("t2 = ");
            print_term(t2);
        }
        printf(";\n");
    }
    else {
        printf("no\n");
    }
}
