extern void number_pair_list(Act_Rec *global, Void_Routine_Descriptor *Action);
