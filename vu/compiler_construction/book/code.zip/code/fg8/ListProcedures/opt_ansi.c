#include    <stdio.h>

#include    "act_rec.h"
#include    "opt_a_number_list.h"

#include    "opt_ansi.i"

int main(void) {
    find_sum(10);
    return 0;
}

