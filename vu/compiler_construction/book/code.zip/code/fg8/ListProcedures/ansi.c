#include    <stdio.h>

#include    "act_rec.h"
#include    "ansi_number_list.h"

#include    "ansi.i"

int main(void) {
    find_sum(Global_Act_Rec, 10);
    return 0;
}

