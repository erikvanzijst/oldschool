#include    "number_list.h"

#include    "nested.i"

int main(void) {
    find_sum(10);
    return 0;
}

