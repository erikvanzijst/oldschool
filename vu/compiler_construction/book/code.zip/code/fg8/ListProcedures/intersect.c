#include    <stdio.h>

#include    "intersect.i"

void diff3(void (*Action)(int v)) {
    (*Action)(1);
    (*Action)(4);
    (*Action)(7);
}

void diff1(void (*Action)(int v)) {
    (*Action)(2);
    (*Action)(3);
    (*Action)(4);
}

void print(int v) {
    printf("Common element: %d\n", v);
}

int main(void) {
    intersect(diff3, diff1, print);
    return 0;
}

