/* General type definitions for activation records */
typedef void *Act_Rec;
#define Global_Act_Rec  ((Act_Rec *)0)

typedef void (*Void_Routine)(Act_Rec parent_act_rec, ...);
typedef struct {
    Void_Routine routine;
    Act_Rec parent_act_rec;
} Void_Routine_Descriptor;
