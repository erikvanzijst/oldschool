extern void number_pair_list(void (*Action)(int v1, int v2));
