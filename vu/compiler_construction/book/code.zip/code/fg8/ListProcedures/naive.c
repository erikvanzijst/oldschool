#include    <stdio.h>

#include    "number_list.h"

#include    "naive.i"

int main(void) {
    find_sum(10);
    return 0;
}

