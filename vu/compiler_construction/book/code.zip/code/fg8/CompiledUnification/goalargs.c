/* ======== goalargs.c for Compiled Unification ======== */
#include    "../SimpleCompiled/goalargs.c"
