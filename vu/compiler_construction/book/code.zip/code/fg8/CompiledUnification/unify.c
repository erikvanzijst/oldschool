/* ======== unify.c for Compiled Unification ======== */
#include    "../FlatUnification/unify.c"
