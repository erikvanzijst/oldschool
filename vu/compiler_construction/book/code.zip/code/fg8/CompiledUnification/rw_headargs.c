/* ======== rw_headargs.c for Compiled Unification ======== */
#include    <stdlib.h>
#include    <malloc.h>

#include    "data.h"
#include    "goalargs.h"
#include    "rw_headargs.h"
#include    "unify.h"

Mode mode = Read_Mode;

int unify_constant(Term **goal_ptr, char *head_text) {
    /* unify *goal_ptr and constant head_text */
    register Term *g;

#include    "rw_unf_constant.i"
    return 1;
L_fail:
    return 0;
}

int unify_variable(Term **goal_ptr, Term *head_var) {
    /* unify *goal_ptr and unbound or bound head variable head_var */
    register Term *g;
    register Term *v;

#include    "rw_unf_variable.i"
    return 1;
L_fail:
    return 0;
}

int unify_structure(Term **goal_ptr, char *head_functor, int head_arity) {
    /* unify *goal_ptr and some struct */
    register Term *g;

#include    "rw_unf_structure.i"
    return 1;
L_fail:
    return 0;
}
