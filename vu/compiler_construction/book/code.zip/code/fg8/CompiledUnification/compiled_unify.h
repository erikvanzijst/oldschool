/* ======== compiled_unify.h for Compiled Unification ======== */
extern int compiled_unify_head_times_2_X(Term *goal_arg);
extern int compiled_unify_head_deriv(Term *goal_arg);

