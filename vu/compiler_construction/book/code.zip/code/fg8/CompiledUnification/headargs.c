/* ======== headargs.c for Compiled Unification ======== */
#include    "data.h"
#include    "goalargs.h"
#include    "headargs.h"

static void initialize_components(Term *term) {
    int i;

    for (i = 0; i < term->term.structure.arity; i++) {
        term->term.structure.components[i] = put_variable("$$$");
    }
}

int unify_constant(Term *goal_arg, char *head_text) {
    register Term *g;
#include    "unify_constant.i"
    return 1;
L_fail:
    return 0;
}

int unify_variable(Term *goal_arg, Term *head_var) {
    register Term *g;
    register Term *v;
#include    "unify_variable.i"
    return 1;
L_fail:
    return 0;
}

int unify_structure(Term *goal_arg, char *head_functor, int head_arity) {
    register Term *g;
#include    "unify_structure.i"
    return 1;
L_fail:
    return 0;
}
