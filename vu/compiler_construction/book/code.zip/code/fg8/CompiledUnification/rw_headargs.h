/* ======== rw_headargs.h for Compiled Unification ======== */
typedef enum {Read_Mode, Write_Mode} Mode;
extern Mode mode;

extern int unify_constant(Term **goal_ptr, char *head_text);
extern int unify_variable(Term **goal_ptr, Term *head_var);
extern int unify_structure(Term **goal_ptr, char *head_functor, int head_arity);

#define UNIFY_CONSTANT(gp,t) if (!unify_constant(gp, t)) goto L_fail
#define UNIFY_VARIABLE(gp,v) if (!unify_variable(gp, v)) goto L_fail
#define UNIFY_STRUCTURE(gp,f,a) if (!unify_structure(gp, f, a)) goto L_fail
