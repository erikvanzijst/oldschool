/* ======== unify_main.c for Compiled Unification ======== */
#include    <stdio.h>

#include    "data.h"
#include    "goalargs.h"
#include    "compiled_unify.h"
#include    "free_var.h"
#include    "print.h"

static void test(Term *goal_arg, int (*compiled_unify)(Term *goal));

int main(void) {
    /* unify goal with head times(2, X) */
    test(
        /* goal times(2, x) */
        put_struct_2("times", put_constant("2"), put_constant("y")),
        compiled_unify_head_times_2_X
    );

    test(put_variable("I"), compiled_unify_head_times_2_X);

    /* unify goal with head deriv(power(X, 2), X, times(2, X)) */
    test(
        /* goal deriv(Y, x, times(Z, x)) */
        put_struct_3(
            "deriv",
            put_variable("Y"),
            put_constant("x"),
            put_struct_2("times", put_variable("Z"), put_constant("x"))
        ),
        compiled_unify_head_deriv
    );

    test(put_variable("I"), compiled_unify_head_deriv);
    test(put_constant("I"), compiled_unify_head_deriv);

    return 0;
}

static void test(Term *goal_arg, int (*compiled_unify)(Term *goal)) {
    printf("Original goal: ");
    print_term(goal_arg); printf("\n");

    clear_free_variable_list();
    if (compiled_unify(goal_arg)) {
        printf("Unified goal: ");
        print_term(goal_arg); printf("\n");
        printf("Bindings of head variables:\n");
        print_term(free_variable("X")); printf("\n");
    }
    else {
        printf("no unifier\n");
    }
    printf("\n");
}
