/* ======== rw_compiled_unify.c for Compiled Unification ======== */
#include    "data.h"
#include    "compiled_unify.h"
#include    "rw_headargs.h"
#include    "unify.h"
#include    "free_var.h"

int compiled_unify_head_times_2_X(Term *goal_arg) {
    /* translation of head times(2, X) */
    Term *X = free_variable("X");
    Mode mode_1;

#include    "rw_times2X.i"

    return 1;
L_fail:
    return 0;
}

int compiled_unify_head_deriv(Term *goal_arg) {
    /* translation of head deriv(power(X, 2), X, times(2, X)) */
    Term *X = free_variable("X");
    Mode mode_1;

#include    "rw_deriv.i"

    return 1;
L_fail:
    return 0;
}
