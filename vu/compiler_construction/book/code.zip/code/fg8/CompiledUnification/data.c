/* ======== data.c for Compiled Unification ======== */
#include    "../SimpleCompiled/data.c"
