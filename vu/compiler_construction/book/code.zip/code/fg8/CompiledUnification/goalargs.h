/* ======== goalargs.h for Compiled Unification ======== */
#include    "../SimpleCompiled/goalargs.h"
