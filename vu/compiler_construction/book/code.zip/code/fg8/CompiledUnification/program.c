/* ======== program.c for Compiled Unification ======== */
/*
    This is a sample C translation of the Prolog program

        grandparent(X, Z) :- parent(X, Y), parent(Y, Z).
        parent(arne, james).
        parent(arne, sachiko).
        parent(koos, rivka).
        parent(sachiko, rivka).
        parent(truitje, koos).

    ?- grandparent(X, rivka).
*/

#include    "data.h"
#include    "action.h"
#include    "trail.h"
#include    "unify.h"
#include    "program.h"
#include    "goalargs.h"
#include    "headargs.h"

#include    "grandparent2.i"
#include    "parent2.i"

