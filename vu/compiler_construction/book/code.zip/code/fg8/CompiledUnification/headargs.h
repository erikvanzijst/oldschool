/* ======== headargs.h for Compiled Unification ======== */
extern int unify_constant(Term *goal_arg, char *head_text);
extern int unify_variable(Term *goal_arg, Term *head_var);
extern int unify_structure(Term *goal_arg, char *head_functor, int head_arity);

#define UNIFY_CONSTANT(g,t) if (!unify_constant(g, t)) goto L_fail
#define UNIFY_VARIABLE(g,v) if (!unify_variable(g, v)) goto L_fail
#define UNIFY_STRUCTURE(g,f,a) if (!unify_structure(g, f, a)) goto L_fail
