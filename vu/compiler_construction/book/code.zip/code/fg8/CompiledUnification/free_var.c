#include    "data.h"
#include    "goalargs.h"

static Term *free_var[10];
int first_free = 0;

Term *free_variable(char *name) {
    int i;

    for (i = 0; i < first_free; i++) {
        if (strcmp(free_var[i]->term.variable.name, name) == 0)
            return free_var[i];
    }
    i = first_free;
    free_var[first_free++] = put_variable(name);
    return free_var[i];
}

void clear_free_variable_list(void) {
    first_free = 0;
}
