extern Term *free_variable(char *name);
extern void clear_free_variable_list(void);
