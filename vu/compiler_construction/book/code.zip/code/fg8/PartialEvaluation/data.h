#include    <strings.h>

#include    "../../fg8/FlatUnification/data.h"
extern int unify_structures(struct structure *s_goal, struct structure *s_head);
