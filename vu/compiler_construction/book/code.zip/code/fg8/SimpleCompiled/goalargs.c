/* ======== goalargs.c for Simple Compiled Prolog Program ======== */
#include    <malloc.h>

#include    "data.h"
#include    "goalargs.h"

Term *put_constant(char *text) {
    Term *term = new_Term();

    term->type = Is_Constant;
    term->term.constant = text;

    return term;
}

Term *put_variable(char *name) {
    Term *term = new_Term();

    term->type = Is_Variable;
    term->term.variable.name = name;
    term->term.variable.term = 0;    /* unbound */

    return term;
}

Term *put_structure(char *functor, int arity) {
    Term *term = new_Term();

    term->type = Is_Structure;
    term->term.structure.functor = functor;
    term->term.structure.arity = arity;
    term->term.structure.components =
        (arity == 0 ? 0 : new_components(arity));

    return term;
}

Term *put_struct_0(char *functor) {
    Term *term = put_structure(functor, 0);

    return term;
}

Term *put_struct_1(char *functor, Term *t1) {
    Term *term = put_structure(functor, 1);

    term->term.structure.components[0] = t1;

    return term;
}

Term *put_struct_2(char *functor, Term *t1, Term *t2) {
    Term *term = put_structure(functor, 2);

    term->term.structure.components[0] = t1;
    term->term.structure.components[1] = t2;

    return term;
}

Term *put_struct_3(char *functor, Term *t1, Term *t2, Term *t3) {
    Term *term = put_structure(functor, 3);

    term->term.structure.components[0] = t1;
    term->term.structure.components[1] = t2;
    term->term.structure.components[2] = t3;

    return term;
}
