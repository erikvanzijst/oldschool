/* ======== programcut.c for Simple Compiled Prolog Program ======== */

/* See program.c; with cut mechanism */

#include    "data.h"
#include    "action.h"
#include    "program.h"
#include    "goalargs.h"
#include    "unify.h"

#include    "firstgp2.i"
#include    "parent2.i"
