#include    <stdio.h>

#include    "data.h"
#include    "goalargs.h"
#include    "print.h"
#include    "action.h"
#include    "program.h"

#include    "test_parent.i"
