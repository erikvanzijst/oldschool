extern void built_in_is(Term *t1, Term *t2, Action goal_list_tail);
