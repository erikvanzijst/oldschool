/* ======== query.c for Simple Compiled Prolog Program ======== */
#include    <stdio.h>

#include    "data.h"
#include    "action.h"
#include    "query.h"
#include    "goalargs.h"
#include    "program.h"
#include    "print.h"

static void test_grandparent(Term *t1, Term *t2);

void query(void) {
    Term *var_X;

    test_unify();

    test_grandparent(put_constant("arne"), put_variable("X"));
    test_grandparent(put_variable("X"), put_constant("rivka"));
    test_grandparent(put_variable("X"), put_variable("Y"));

    var_X = put_variable("X");
    test_grandparent(var_X, var_X);
}

static void test_grandparent(Term *t1, Term *t2) {

    void query_action(void) {
        if (t1) {
            printf("t1 = ");
            print_term(t1);
        }

        if (t2) {
            printf(", ");
            printf("t2 = ");
            print_term(t2);
        }
        printf(";\n");
    }

    printf("?- grandparent(");
    print_term(t1);
    printf(", ");
    print_term(t2);
    printf(").\n");
    grandparent_2(t1, t2, query_action);
    printf("no\n");
}
