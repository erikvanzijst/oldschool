extern void built_in_var(Term *t, Action goal_list_tail);
