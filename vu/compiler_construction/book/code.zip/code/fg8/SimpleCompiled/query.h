/* ======== query.h for Simple Compiled Prolog Program ======== */
extern void query(void);
