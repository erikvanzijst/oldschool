/* ======== print.c for Simple Compiled Prolog Program ======== */
#include    <stdio.h>

#include    "data.h"
#include    "print.h"

void print_term(Term *t) {
    if (t == 0) {
        printf("<<<< Bad Term >>>>");
        return;
    }

    switch (t->type) {
    case Is_Constant:
        printf("%s", t->term.constant);
        break;
    case Is_Variable:
        printf("%s ", t->term.variable.name);
        if (t->term.variable.term == 0) {
            printf("unbound");
        }
        else {
            printf("= ");
            print_term(t->term.variable.term);
        }
        break;
    case Is_Structure:
        {   int i;

            printf("%s(", t->term.structure.functor);
            for (i = 0; i < t->term.structure.arity; i++) {
                if (i > 0) {
                    printf(", ");
                }
                print_term(t->term.structure.components[i]);
            }
            printf(")");
        }
        break;
    }
}
