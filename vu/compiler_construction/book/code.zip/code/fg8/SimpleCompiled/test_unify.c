/* ======== test_unify.c for Simple Compiled Prolog Program ======== */
#include    <stdio.h>

#include    "data.h"
#include    "test_unify.h"
#include    "goalargs.h"
#include    "test_unify_terms.h"

void test_unify(void) {
    Term *var_X;
    Term *var_Y;

    var_X = put_variable("X");
    test_unify_terms(var_X, put_constant("aap"));

    var_X = put_variable("X");
    var_Y = put_variable("Y");
    test_unify_terms(
        put_struct_2("aap", var_X, var_X),
        put_struct_2("aap", var_Y, put_constant("mies"))
    );

    var_X = put_variable("X");
    test_unify_terms(
        put_struct_2("aap", var_X, var_X),
        put_struct_2("aap", put_constant("mies"), put_constant("mies"))
    );

    var_X = put_variable("X");
    test_unify_terms(
        put_struct_2("aap", put_constant("mies"), var_X),
        put_struct_2("aap", var_X, put_constant("mies"))
    );
}
