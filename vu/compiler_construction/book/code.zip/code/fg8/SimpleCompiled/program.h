/* ======== program.h for Simple Compiled Prolog Program ======== */
extern void grandparent_2(Term *goal_arg1, Term *goal_arg2, Action goal_list_tail);
extern void parent_2(Term *goal_arg1, Term *goal_arg2, Action goal_list_tail);
