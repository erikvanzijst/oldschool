/* ======== test_unify.h for Simple Compiled Prolog Program ======== */
extern void test_unify(void);
