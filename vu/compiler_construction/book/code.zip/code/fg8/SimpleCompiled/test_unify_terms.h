/* ======== test_unify_terms.h for Simple Compiled Prolog Program ======== */
extern void test_unify_terms(Term *t1, Term *t2);
