/* ======== main.c for Simple Compiled Prolog Program ======== */
#include    <stdio.h>

#include    "query.h"

static int parent_call_count = 0;

void count_parent_call(void) {
    parent_call_count++;
}

int main(void) {
    query();
    printf("# calls to parent(): %d\n", parent_call_count);
    return 0;
}
