/* ======== data.h for Simple Compiled Prolog Program ======== */

#include    "data.i"

/* auxiliaries */
#define new_components(n)     ((Term **)malloc(n * sizeof (Term *)))
#define new_Term()            ((Term *)malloc(sizeof (Term)))
extern Term *deref(Term *t);
