/* ======== test_unify_terms.c for Simple Compiled Prolog Program ======== */
#include    <stdio.h>

#include    "data.h"
#include    "action.h"
#include    "test_unify_terms.h"
#include    "goalargs.h"
#include    "unify.h"
#include    "print.h"

void test_unify_terms(Term *t1, Term *t2) {

    void query_action(void) {
        if (t1) {
            printf("t1 = ");
            print_term(t1);
        }

        if (t2) {
            printf(", ");
            printf("t2 = ");
            print_term(t2);
        }
        printf(";\n");
    }

    printf("?- unify_terms(");
    print_term(t1);
    printf(", ");
    print_term(t2);
    printf(").\n");
    unify_terms(t1, t2, query_action);
}
