extern void built_in_between(Term *t1, Term *t2, Term *t3, Action goal_list_tail);
