/* ======== print.h for Simple Compiled Prolog Program ======== */
extern void print_term(Term *t);
