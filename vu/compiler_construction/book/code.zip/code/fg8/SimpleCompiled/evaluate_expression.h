extern Term *evaluate_expression(Term *t);
