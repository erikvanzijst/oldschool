/* ======== goalargs.h for Simple Compiled Prolog Program ======== */
extern Term *put_constant(char *text);
extern Term *put_variable(char *name);
extern Term *put_structure(char *functor, int arity);
extern Term *put_struct_0(char *functor);
extern Term *put_struct_1(char *functor, Term *t1);
extern Term *put_struct_2(char *functor, Term *t1, Term *t2);
extern Term *put_struct_3(char *functor, Term *t1, Term *t2, Term *t3);
