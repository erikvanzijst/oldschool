/* ======== unify.c for Simple Compiled Prolog Program ======== */
#include    "data.h"
#include    "action.h"
#include    "unify.h"

#include    "unify_unbound_variable.i"
#include    "unify_structures.i"
#include    "unify_non_variables.i"
#include    "unify_terms.i"
