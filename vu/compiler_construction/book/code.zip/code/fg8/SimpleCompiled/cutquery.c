/* ======== cutquery.c for Simple Compiled Prolog Program ======== */
#include    <stdio.h>

#include    "data.h"
#include    "action.h"
#include    "query.h"
#include    "goalargs.h"
#include    "program.h"
#include    "print.h"

static void test_first_gp(Term *t1, Term *t2);

void query(void) {
    Term *var_X;

    test_first_gp(put_constant("truitje"), put_variable("X"));
    test_first_gp(put_constant("arne"), put_variable("X"));
    test_first_gp(put_variable("X"), put_variable("Y"));
}

static void test_first_gp(Term *t1, Term *t2) {

    void query_action(void) {
        if (t1) {
            printf("t1 = ");
            print_term(t1);
        }

        if (t2) {
            printf(", ");
            printf("t2 = ");
            print_term(t2);
        }
        printf(";\n");
    }

    printf("?- first_gp(");
    print_term(t1);
    printf(", ");
    print_term(t2);
    printf(").\n");
    first_gp_2(t1, t2, query_action);
    printf("no\n");
}
