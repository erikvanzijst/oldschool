/* ======== action.h for Simple Compiled Prolog Program ======== */
typedef void (*Action)(void);
