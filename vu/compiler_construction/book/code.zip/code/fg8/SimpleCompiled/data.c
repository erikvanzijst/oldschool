/* ======== data.c for Simple Compiled Prolog Program ======== */
#include    "data.h"
#include    "deref.i"
