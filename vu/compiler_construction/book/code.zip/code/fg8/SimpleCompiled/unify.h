/* ======== unify.h for Simple Compiled Prolog Program ======== */
extern void unify_terms(Term *goal_arg, Term *head_arg, Action goal_list_tail);
