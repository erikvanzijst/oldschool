/* ======== programswitch.c for Simple Compiled Prolog Program ======== */

/* See program.c; with optimized clause selection */

#include    "data.h"
#include    "action.h"
#include    "program.h"
#include    "goalargs.h"
#include    "unify.h"

#include    "grandparent2.i"
#include    "parent2switch.i"
