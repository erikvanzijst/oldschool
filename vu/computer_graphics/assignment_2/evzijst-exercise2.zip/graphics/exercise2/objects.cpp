#include "objects.h"

/*
 * This file implements the static objects (pyramid and cube).
 */
void createPyramid(void)
{

}

void createCube(void)
{
}
