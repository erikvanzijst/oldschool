#ifndef __LOADER_H
#define __LOADER_H

long load(char **files, int name);

#endif __LOADER_H
