	Computer Graphics

	Exercise 1: the basics


This directory contains the submission for exercise 1.
The program implements all required features, together with the minor addition
that the right-button context menu allows the user to change both the color
and the thickness of the wireframe cube.

Internally the program uses OpenGL call lists to store the object definitions.
This proved to be a convenient way to create objects in the program, while
avoiding the overhead of building the object again in each frame.

Erik van Zijst - erik@marketxs.com - 1351745
10.oct.2004
