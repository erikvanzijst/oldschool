/*
 * Computer Graphics Course 2004
 *
 * Exercise 2
 *
 * Erik van Zijst - 1351745 - erik@marketxs.com - 06.oct.2004
 */

#ifndef __MENU_H
#define __MENU_H

void createMenu(void);

#endif __MENU_H
