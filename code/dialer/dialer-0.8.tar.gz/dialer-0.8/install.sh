gcc -lqt -o dialer ./dialer.cc
